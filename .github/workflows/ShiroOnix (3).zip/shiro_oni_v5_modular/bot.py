"""
Shiro Oni Chk V5 - Modular CC Checker Bot
Owner: @diwasxd
Version: v5.0.0 Modular
"""

import asyncio
import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from telethon import TelegramClient, events, Button
from telethon.tl.types import DocumentAttributeFilename

import config
from handlers import command_handler, gateway_handler
from utils.helpers import get_user_stats, load_json, save_json
from utils.card_parser import parse_cards_from_text

# Initialize bot
bot = TelegramClient('shiro_oni_bot', config.API_ID, config.API_HASH).start(bot_token=config.BOT_TOKEN)

print(f"✅ {config.BOT_NAME} {config.BOT_VERSION} started successfully!")
print(f"Owner: {config.OWNER_USERNAME} ({config.OWNER_ID})")

# ==================== AUTHORIZATION SYSTEM ====================

async def is_authorized(user_id: int) -> bool:
    """Check if user is authorized"""
    
    # Owner is always authorized
    if user_id == config.OWNER_ID:
        return True
    
    # If auth not required, allow all
    if not config.REQUIRE_AUTH:
        return True
    
    # Check authorized users file
    try:
        authorized_users = await load_json(config.AUTHORIZED_USERS_FILE)
        return str(user_id) in authorized_users.get('users', [])
    except:
        return False


async def add_authorized_user(user_id: int):
    """Add user to authorized list"""
    
    try:
        authorized_users = await load_json(config.AUTHORIZED_USERS_FILE)
    except:
        authorized_users = {'users': []}
    
    if str(user_id) not in authorized_users['users']:
        authorized_users['users'].append(str(user_id))
        await save_json(config.AUTHORIZED_USERS_FILE, authorized_users)
        return True
    return False


async def remove_authorized_user(user_id: int):
    """Remove user from authorized list"""
    
    try:
        authorized_users = await load_json(config.AUTHORIZED_USERS_FILE)
        if str(user_id) in authorized_users['users']:
            authorized_users['users'].remove(str(user_id))
            await save_json(config.AUTHORIZED_USERS_FILE, authorized_users)
            return True
    except:
        pass
    return False


async def get_authorized_users():
    """Get list of authorized users"""
    
    try:
        authorized_users = await load_json(config.AUTHORIZED_USERS_FILE)
        return authorized_users.get('users', [])
    except:
        return []


# ==================== ADMIN COMMANDS ====================

@bot.on(events.NewMessage(pattern='/auth'))
async def auth_command(event):
    """Authorize a user - Admin only"""
    
    user_id = event.sender_id
    
    # Only owner can authorize
    if user_id != config.OWNER_ID:
        await event.respond("❌ You are not authorized to use this command")
        return
    
    # Get user ID from command
    parts = event.message.text.split()
    if len(parts) < 2:
        await event.respond("❌ Usage: /auth <user_id>")
        return
    
    try:
        target_user_id = int(parts[1])
    except:
        await event.respond("❌ Invalid user ID")
        return
    
    # Add user
    added = await add_authorized_user(target_user_id)
    
    if added:
        await event.respond(f"✅ User {target_user_id} has been authorized!")
    else:
        await event.respond(f"⚠️ User {target_user_id} is already authorized")


@bot.on(events.NewMessage(pattern='/unauth'))
async def unauth_command(event):
    """Remove authorization from a user - Admin only"""
    
    user_id = event.sender_id
    
    # Only owner can unauthorize
    if user_id != config.OWNER_ID:
        await event.respond("❌ You are not authorized to use this command")
        return
    
    # Get user ID from command
    parts = event.message.text.split()
    if len(parts) < 2:
        await event.respond("❌ Usage: /unauth <user_id>")
        return
    
    try:
        target_user_id = int(parts[1])
    except:
        await event.respond("❌ Invalid user ID")
        return
    
    # Remove user
    removed = await remove_authorized_user(target_user_id)
    
    if removed:
        await event.respond(f"✅ User {target_user_id} has been unauthorized!")
    else:
        await event.respond(f"⚠️ User {target_user_id} was not authorized")


@bot.on(events.NewMessage(pattern='/authlist'))
async def authlist_command(event):
    """List all authorized users - Admin only"""
    
    user_id = event.sender_id
    
    # Only owner can view list
    if user_id != config.OWNER_ID:
        await event.respond("❌ You are not authorized to use this command")
        return
    
    # Get authorized users
    authorized_users = await get_authorized_users()
    
    if not authorized_users:
        await event.respond("📋 No authorized users")
        return
    
    message = "📋 **Authorized Users:**\n\n"
    for i, uid in enumerate(authorized_users, 1):
        message += f"{i}. User ID: `{uid}`\n"
    
    await event.respond(message)


@bot.on(events.NewMessage(pattern='/broadcast'))
async def broadcast_command(event):
    """Broadcast message to all authorized users - Admin only"""
    
    user_id = event.sender_id
    
    # Only owner can broadcast
    if user_id != config.OWNER_ID:
        await event.respond("❌ You are not authorized to use this command")
        return
    
    # Get message
    parts = event.message.text.split(maxsplit=1)
    if len(parts) < 2:
        await event.respond("❌ Usage: /broadcast <message>")
        return
    
    message = parts[1]
    
    # Get authorized users
    authorized_users = await get_authorized_users()
    
    if not authorized_users:
        await event.respond("❌ No authorized users to broadcast to")
        return
    
    # Broadcast
    success_count = 0
    fail_count = 0
    
    for uid in authorized_users:
        try:
            await bot.send_message(int(uid), f"📢 **Broadcast from Admin:**\n\n{message}")
            success_count += 1
        except:
            fail_count += 1
    
    await event.respond(f"✅ Broadcast complete!\n\nSuccess: {success_count}\nFailed: {fail_count}")


# ==================== START COMMAND ====================

@bot.on(events.NewMessage(pattern='/start'))
async def start_handler(event):
    """Handle /start command"""
    
    user_id = event.sender_id
    
    # Check authorization
    if not await is_authorized(user_id):
        await event.respond(
            f"❌ **Access Denied**\n\n"
            f"You are not authorized to use this bot.\n"
            f"Your User ID: `{user_id}`\n\n"
            f"Contact {config.OWNER_USERNAME} for access."
        )
        return
    
    user_stats = await get_user_stats(user_id)
    
    result = await command_handler.handle_start_command(user_id, user_stats)
    
    try:
        await bot.send_file(
            event.chat_id,
            result['image_url'],
            caption=result['message'],
            buttons=result['buttons']
        )
    except:
        # If image fails, send without image
        await event.respond(result['message'], buttons=result['buttons'])


# ==================== GATEWAY COMMANDS ====================

@bot.on(events.NewMessage(pattern=r'/(\w+)\s*(.*)'))
async def command_router(event):
    """Route commands to appropriate handlers"""
    
    user_id = event.sender_id
    message_text = event.message.text
    
    # Parse command and args
    parts = message_text.split(maxsplit=1)
    command = parts[0][1:]  # Remove /
    args = parts[1] if len(parts) > 1 else ''
    
    # Skip /start and admin commands (handled separately)
    if command in ['start', 'auth', 'unauth', 'authlist', 'broadcast']:
        return
    
    # Check authorization for all other commands
    if not await is_authorized(user_id):
        await event.respond(
            f"❌ **Access Denied**\n\n"
            f"You are not authorized to use this bot.\n"
            f"Your User ID: `{user_id}`\n\n"
            f"Contact {config.OWNER_USERNAME} for access."
        )
        return
    
    # Check if it's a gateway command
    if command in config.GATEWAY_COMMANDS:
        result = await command_handler.handle_gateway_command(command, args, user_id)
        
        if result['type'] == 'error':
            await event.respond(result['message'])
        else:
            # Send processing message
            processing_msg = await event.respond(result['processing_message'])
            
            # Get result
            gateway_result = result['result']
            
            if gateway_result['formatted_response']:
                # Delete processing message
                await processing_msg.delete()
                
                # Send formatted response
                await event.respond(gateway_result['formatted_response'])
            else:
                # Update processing message with error
                await processing_msg.edit(f"❌ {gateway_result['message']}")
    
    # Check if it's a mass command
    elif command.startswith('mass'):
        result = await command_handler.handle_mass_command(command, args, user_id)
        
        if result['type'] == 'error':
            await event.respond(result['message'])
        else:
            # Send initial message
            status_msg = await event.respond(f"🔄 Starting mass check for {len(result['cards'])} cards...")
            
            # Process cards
            async for progress in gateway_handler.mass_check_cards(result['cards'], result['gateway_name'], user_id):
                # Send result for each card
                if progress['result']['formatted_response']:
                    await event.respond(progress['result']['formatted_response'])
                
                # Update status
                await status_msg.edit(f"🔄 Progress: {progress['index']}/{progress['total']}")
            
            # Final message
            await status_msg.edit(f"✅ Mass check complete! Checked {progress['total']} cards.")
    
    # Check if it's a tool command
    elif command in config.TOOL_COMMANDS:
        # Get replied message for filter/binex
        replied_msg = await event.get_reply_message()
        cards = []
        
        if replied_msg:
            cards = parse_cards_from_text(replied_msg.text, 100)
        
        result = await command_handler.handle_tool_command(command, args, user_id, cards=cards)
        
        if result['type'] == 'error':
            await event.respond(result['message'])
        elif result['type'] == 'tool_result':
            await event.respond(result['result'])
        elif result['type'] == 'screenshot_result':
            if result['result']['success']:
                await bot.send_file(
                    event.chat_id,
                    result['result']['image_path'],
                    caption=f"📸 Screenshot of {args}"
                )
            else:
                await event.respond(f"❌ Screenshot failed: {result['result']['error']}")
    
    # Check if it's a site management command
    elif command in ['seturl', 'vurl', 'rmurl']:
        result = await command_handler.handle_site_command(command, args, user_id)
        await event.respond(result['message'])


# ==================== TXT FILE HANDLER ====================

@bot.on(events.NewMessage)
async def file_handler(event):
    """Handle TXT file uploads for mass check"""
    
    if event.document:
        user_id = event.sender_id
        
        # Check authorization
        if not await is_authorized(user_id):
            return
        
        # Check if it's a TXT file
        filename = None
        for attr in event.document.attributes:
            if isinstance(attr, DocumentAttributeFilename):
                filename = attr.file_name
                break
        
        if filename and filename.endswith('.txt'):
            # Download file
            file_path = await event.download_media()
            
            # Read cards
            with open(file_path, 'r') as f:
                cards_text = f.read()
            
            cards = parse_cards_from_text(cards_text, config.TXT_FILE_LIMIT)
            
            if not cards:
                await event.respond("❌ No valid cards found in file")
                return
            
            # Ask which gateway to use
            await event.respond(
                f"✅ Found {len(cards)} cards in file\n\n"
                f"Use /mass<gateway> to check them\n"
                f"Example: /masssh for Shopify"
            )
            
            # Clean up
            os.remove(file_path)


# ==================== BUTTON CALLBACKS ====================

@bot.on(events.CallbackQuery)
async def button_callback_handler(event):
    """Handle inline button callbacks"""
    
    user_id = event.sender_id
    
    # Check authorization
    if not await is_authorized(user_id):
        await event.answer("❌ Access Denied", alert=True)
        return
    
    callback_data = event.data.decode('utf-8')
    
    result = await command_handler.handle_button_callback(callback_data, user_id)
    
    if result['type'] == 'start':
        try:
            await event.edit(
                result['message'],
                buttons=result['buttons'],
                file=result['image_url']
            )
        except:
            await event.edit(result['message'], buttons=result['buttons'])
    
    elif result['type'] == 'menu':
        await event.edit(result['message'], buttons=result.get('buttons'))
    
    elif result['type'] == 'close':
        await event.delete()
    
    elif result['type'] == 'error':
        await event.answer(result['message'], alert=True)


# ==================== MAIN ====================

def main():
    """Main function - Fixed for asyncio"""
    
    print(f"🚀 Starting {config.BOT_NAME} {config.BOT_VERSION}...")
    print(f"Owner: {config.OWNER_USERNAME} ({config.OWNER_ID})")
    print("━━━━━━━━━━━━━━━━━━━━━━")
    
    # List available gateways
    gateways = gateway_handler.get_available_gateways()
    print(f"✅ Loaded {len(gateways)} gateways")
    
    # Create data directory
    os.makedirs("data", exist_ok=True)
    
    print("━━━━━━━━━━━━━━━━━━━━━━")
    print(f"✅ {config.BOT_NAME} is now running!")
    print("Press Ctrl+C to stop")
    
    # Run bot (fixed asyncio)
    bot.run_until_disconnected()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n👋 {config.BOT_NAME} stopped by user")
    except Exception as e:
        print(f"❌ Error: {e}")
