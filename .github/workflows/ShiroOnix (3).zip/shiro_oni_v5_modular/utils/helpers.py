"""
Helper Functions
"""

import json
import os
import aiofiles
from datetime import datetime

async def create_json_file(filename: str):
    """Create JSON file if it doesn't exist"""
    try:
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        if not os.path.exists(filename):
            async with aiofiles.open(filename, "w") as f:
                await f.write(json.dumps({}))
    except Exception as e:
        print(f"Error creating {filename}: {e}")

async def load_json(filename: str) -> dict:
    """Load JSON file"""
    try:
        if not os.path.exists(filename):
            await create_json_file(filename)
            return {}
        async with aiofiles.open(filename, 'r') as f:
            content = await f.read()
            return json.loads(content) if content else {}
    except Exception as e:
        print(f"Error loading {filename}: {e}")
        return {}

async def save_json(filename: str, data: dict):
    """Save data to JSON file"""
    try:
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        async with aiofiles.open(filename, 'w') as f:
            await f.write(json.dumps(data, indent=2))
    except Exception as e:
        print(f"Error saving {filename}: {e}")

async def log_approved_card(card: str, gateway: str):
    """Log approved card to file"""
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {gateway}: {card}\n"
        
        os.makedirs("data", exist_ok=True)
        async with aiofiles.open("data/approved_cards.txt", "a") as f:
            await f.write(log_entry)
    except Exception as e:
        print(f"Error logging approved card: {e}")

def get_country_flag(country_code: str) -> str:
    """Get country flag emoji from country code"""
    
    flags = {
        "US": "🇺🇸", "GB": "🇬🇧", "CA": "🇨🇦", "AU": "🇦🇺",
        "IN": "🇮🇳", "DE": "🇩🇪", "FR": "🇫🇷", "IT": "🇮🇹",
        "ES": "🇪🇸", "BR": "🇧🇷", "MX": "🇲🇽", "AR": "🇦🇷",
        "JP": "🇯🇵", "CN": "🇨🇳", "KR": "🇰🇷", "RU": "🇷🇺",
        "AE": "🇦🇪", "SA": "🇸🇦", "TR": "🇹🇷", "ZA": "🇿🇦",
    }
    
    return flags.get(country_code.upper(), "🌍")

def format_time(seconds: float) -> str:
    """Format time in seconds to readable string"""
    
    if seconds < 1:
        return f"{int(seconds * 1000)}ms"
    elif seconds < 60:
        return f"{seconds:.2f}s"
    else:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes}m {secs}s"

def truncate_text(text: str, max_length: int = 100) -> str:
    """Truncate text to max length"""
    
    if len(text) <= max_length:
        return text
    
    return text[:max_length - 3] + "..."

async def get_user_stats(user_id: int) -> dict:
    """Get user statistics"""
    
    stats = await load_json("data/stats.json")
    
    if str(user_id) not in stats:
        stats[str(user_id)] = {
            "total_checks": 0,
            "approved": 0,
            "declined": 0,
            "total_sites": 0,
            "join_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        await save_json("data/stats.json", stats)
    
    return stats[str(user_id)]

async def update_user_stats(user_id: int, status: str):
    """Update user statistics"""
    
    stats = await load_json("data/stats.json")
    
    if str(user_id) not in stats:
        stats[str(user_id)] = {
            "total_checks": 0,
            "approved": 0,
            "declined": 0,
            "total_sites": 0,
            "join_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    
    stats[str(user_id)]["total_checks"] += 1
    
    if status.lower() in ["charged", "approved"]:
        stats[str(user_id)]["approved"] += 1
    else:
        stats[str(user_id)]["declined"] += 1
    
    await save_json("data/stats.json", stats)

# Test
if __name__ == '__main__':
    print(get_country_flag("US"))
    print(format_time(2.5))
    print(format_time(125.7))
    print(truncate_text("This is a very long text that needs to be truncated", 20))
