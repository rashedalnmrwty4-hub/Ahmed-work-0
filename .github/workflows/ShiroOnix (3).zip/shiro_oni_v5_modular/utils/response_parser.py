"""
Response Parser with Keyword-Based Detection
Properly parses API responses and extracts status
"""

import json
import re

def parse_response(response_text, gateway_name):
    """
    Parse API response and extract status, message
    
    Args:
        response_text: Raw response from API (JSON or text)
        gateway_name: Name of the gateway
        
    Returns:
        dict: {status, message, raw_response}
    """
    
    # Try to parse as JSON first
    try:
        if isinstance(response_text, dict):
            data = response_text
        else:
            data = json.loads(response_text)
            
        # Extract fields
        status = data.get('Status', data.get('status', 'Unknown'))
        message = data.get('Message', data.get('message', data.get('response', 'No response')))
        
        # Keyword-based detection
        status_clean, message_clean = detect_status_by_keywords(status, message, gateway_name)
        
        return {
            'status': status_clean,
            'message': message_clean,
            'raw_response': data
        }
        
    except (json.JSONDecodeError, TypeError):
        # Not JSON, treat as text
        status_clean, message_clean = detect_status_by_keywords('Unknown', str(response_text), gateway_name)
        
        return {
            'status': status_clean,
            'message': message_clean,
            'raw_response': response_text
        }


def detect_status_by_keywords(status, message, gateway_name):
    """
    Detect actual status based on keywords in response
    
    Returns:
        tuple: (status, message)
    """
    
    # Convert to lowercase for matching
    msg_lower = str(message).lower()
    status_lower = str(status).lower()
    combined = f"{status_lower} {msg_lower}"
    
    # ==================== CHARGED/APPROVED KEYWORDS ====================
    charged_keywords = [
        'success', 'charged', 'approved', 'payment successful', 'transaction successful',
        'payment complete', 'order placed', 'thank you', 'confirmed', 'succeeded',
        'payment received', 'captured', 'authorized and captured'
    ]
    
    for keyword in charged_keywords:
        if keyword in combined:
            return 'Charged', extract_clean_message(message, 'charged')
    
    # ==================== APPROVED (Auth) KEYWORDS ====================
    approved_keywords = [
        'card is live', '3ds', 'authentication required', 'requires action',
        'requires payment method', 'card valid', 'approved'
    ]
    
    for keyword in approved_keywords:
        if keyword in combined:
            return 'Approved', extract_clean_message(message, 'approved')
    
    # ==================== DECLINED KEYWORDS ====================
    declined_keywords = [
        'declined', 'card_declined', 'insufficient', 'invalid', 'expired',
        'do not honor', 'pickup', 'restricted', 'security violation',
        'lost card', 'stolen card', 'fraud', 'blocked', 'incorrect',
        'authentication_required', 'card not supported', 'processing error'
    ]
    
    for keyword in declined_keywords:
        if keyword in combined:
            return 'Declined', extract_clean_message(message, 'declined')
    
    # ==================== GATEWAY-SPECIFIC DETECTION ====================
    
    # Shopify
    if 'shopify' in gateway_name.lower():
        if 'success' in combined:
            return 'Charged', 'Card Charged Successfully'
        elif 'card_declined' in combined or 'declined' in combined:
            return 'Declined', 'Card Declined'
    
    # Razorpay
    if 'razorpay' in gateway_name.lower():
        if 'success' in combined or 'payment successful' in combined:
            return 'Charged', 'Payment Successful'
        elif 'failed' in combined or 'declined' in combined:
            return 'Declined', 'Payment Failed'
    
    # Stripe
    if 'stripe' in gateway_name.lower():
        if 'succeeded' in combined or 'success' in combined:
            return 'Charged', 'Payment Succeeded'
        elif 'requires_action' in combined or '3ds' in combined:
            return 'Approved', 'Card is Live (3DS Auth Required)'
        elif 'card_declined' in combined:
            return 'Declined', 'Card Declined'
    
    # Killer (special case - shows KILLED status)
    if 'killer' in gateway_name.lower():
        if 'killed' in combined or 'success' in combined:
            return 'KILLED', 'Card Killed Successfully'
        else:
            return 'Declined', 'Kill Failed'
    
    # ==================== DEFAULT ====================
    # If no keywords matched, use original status
    if 'success' in status_lower:
        return 'Charged', message
    elif 'fail' in status_lower or 'error' in status_lower:
        return 'Declined', message
    else:
        return 'Unknown', message


def extract_clean_message(message, status_type):
    """
    Extract clean message without JSON or technical details
    """
    
    # If message is too long or looks like JSON, create clean message
    if len(str(message)) > 200 or '{' in str(message):
        if status_type == 'charged':
            return 'Payment Successful'
        elif status_type == 'approved':
            return 'Card is Live (3DS Auth Required)'
        elif status_type == 'declined':
            return 'Card Declined'
        else:
            return 'Unknown Status'
    
    # Clean up common patterns
    clean = str(message)
    clean = re.sub(r'\{.*?\}', '', clean)  # Remove JSON
    clean = re.sub(r'\[.*?\]', '', clean)  # Remove arrays
    clean = clean.strip()
    
    # If empty after cleaning, use default
    if not clean:
        if status_type == 'charged':
            return 'Payment Successful'
        elif status_type == 'approved':
            return 'Card is Live'
        elif status_type == 'declined':
            return 'Card Declined'
    
    return clean


def format_response_for_telegram(card, status, message, gateway, price, bin_info, time_taken):
    """
    Format response in Ex bot style
    
    Returns:
        str: Formatted message for Telegram
    """
    
    # Status emoji
    if status == 'Charged':
        emoji = '✅'
        status_text = f'{emoji} 𝗖𝗛𝗔𝗥𝗚𝗘𝗗 {emoji}'
    elif status == 'Approved':
        emoji = '✅'
        status_text = f'{emoji} 𝗔𝗣𝗣𝗥𝗢𝗩𝗘𝗗 {emoji}'
    elif status == 'KILLED':
        emoji = '💀'
        status_text = f'{emoji} 𝗞𝗜𝗟𝗟𝗘𝗗 {emoji}'
    else:
        emoji = '❌'
        status_text = f'{emoji} 𝗗𝗘𝗖𝗟𝗜𝗡𝗘𝗗 {emoji}'
    
    # Format message
    response = f"""━━━━━━━━━━━━━━━━━━━━━━
{status_text}
━━━━━━━━━━━━━━━━━━━━━━

𝗖𝗮𝗿𝗱 ➜ {card}
𝗦𝘁𝗮𝘁𝘂𝘀 ➜ {emoji} {status}
𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ {message}
𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ➜ {gateway}
𝗣𝗿𝗶𝗰𝗲 ➜ {price}

𝗕𝗜𝗡 𝗜𝗻𝗳𝗼
⤷ 𝗕𝗿𝗮𝗻𝗱 ➜ {bin_info.get('brand', 'Unknown')} | {bin_info.get('type', 'Unknown')} | {bin_info.get('level', 'Unknown')}
⤷ 𝗕𝗮𝗻𝗸 ➜ {bin_info.get('bank', 'Unknown')}
⤷ 𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ➜ {bin_info.get('country', 'Unknown')} {bin_info.get('flag', '')}

𝗧𝗶𝗺𝗲 ➜ {time_taken}s
𝗕𝗼𝘁 𝗕𝘆 ➜ @diwasxd
"""
    
    return response


# Test function
if __name__ == '__main__':
    # Test Shopify response
    shopify_response = '{"Status":"Success","Gateway":"Shopify","Price":"0.98","Message":"Card Charged Successfully","Retries":0}'
    result = parse_response(shopify_response, 'shopify')
    print(f"Shopify: {result}")
    
    # Test Razorpay response
    razorpay_response = '{"Status":"Success","Gateway":"Razorpay","Price":"₹1","Message":"Payment Successful"}'
    result = parse_response(razorpay_response, 'razorpay')
    print(f"Razorpay: {result}")
    
    # Test declined
    declined_response = '{"Status":"Failed","Message":"Card Declined (CARD_DECLINED)"}'
    result = parse_response(declined_response, 'stripe')
    print(f"Declined: {result}")
