"""
Card Parser - Parse card details from various formats
"""

import re
from typing import Dict, List, Optional

def parse_card(card_string: str) -> Optional[Dict[str, str]]:
    """
    Parse card from string in format: cc|mm|yy|cvv or cc|mm|yyyy|cvv
    
    Returns:
        dict: {number, exp_month, exp_year, cvc} or None if invalid
    """
    
    # Remove spaces and extra characters
    card_string = card_string.strip().replace(" ", "")
    
    # Try different separators
    separators = ["|", "/", ":", ";", ","]
    
    for sep in separators:
        if sep in card_string:
            parts = card_string.split(sep)
            
            if len(parts) >= 4:
                cc = parts[0].strip()
                mm = parts[1].strip()
                yy = parts[2].strip()
                cvv = parts[3].strip()
                
                # Validate
                if not cc.isdigit() or len(cc) < 13 or len(cc) > 19:
                    continue
                    
                if not mm.isdigit() or int(mm) < 1 or int(mm) > 12:
                    continue
                    
                if not yy.isdigit():
                    continue
                    
                # Handle year format
                if len(yy) == 4:
                    yy = yy[2:]  # Convert 2025 to 25
                elif len(yy) != 2:
                    continue
                    
                if not cvv.isdigit() or len(cvv) < 3 or len(cvv) > 4:
                    continue
                
                return {
                    'number': cc,
                    'exp_month': mm.zfill(2),  # Ensure 2 digits
                    'exp_year': yy,
                    'cvc': cvv
                }
    
    return None


def parse_cards_from_text(text: str, limit: int = 10) -> List[Dict[str, str]]:
    """
    Parse multiple cards from text
    
    Returns:
        list: List of card dicts, max `limit` cards
    """
    
    cards = []
    lines = text.split('\n')
    
    for line in lines:
        if len(cards) >= limit:
            break
            
        card = parse_card(line)
        if card:
            cards.append(card)
    
    return cards


def format_card(card: Dict[str, str]) -> str:
    """
    Format card dict to string: cc|mm|yy|cvv
    """
    return f"{card['number']}|{card['exp_month']}|{card['exp_year']}|{card['cvc']}"


def mask_card(card_number: str) -> str:
    """
    Mask card number: 4532********9012
    """
    if len(card_number) < 8:
        return card_number
        
    return f"{card_number[:4]}{'*' * (len(card_number) - 8)}{card_number[-4:]}"


def get_card_brand(card_number: str) -> str:
    """
    Get card brand from number
    """
    
    if not card_number or not card_number[0].isdigit():
        return "Unknown"
    
    first_digit = card_number[0]
    first_two = card_number[:2] if len(card_number) >= 2 else card_number
    
    # Visa
    if first_digit == '4':
        return "VISA"
    
    # Mastercard
    if first_two in ['51', '52', '53', '54', '55'] or (first_two >= '22' and first_two <= '27'):
        return "MASTERCARD"
    
    # American Express
    if first_two in ['34', '37']:
        return "AMEX"
    
    # Discover
    if first_two == '65' or card_number[:4] == '6011':
        return "DISCOVER"
    
    # JCB
    if first_two == '35':
        return "JCB"
    
    # Diners Club
    if first_two in ['36', '38']:
        return "DINERS"
    
    return "Unknown"


def validate_luhn(card_number: str) -> bool:
    """
    Validate card number using Luhn algorithm
    """
    
    if not card_number.isdigit():
        return False
    
    # Reverse the card number
    digits = [int(d) for d in card_number][::-1]
    
    # Double every second digit
    checksum = 0
    for i, digit in enumerate(digits):
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        checksum += digit
    
    return checksum % 10 == 0


# Test
if __name__ == '__main__':
    test_cards = [
        "4532123456789012|12|25|123",
        "5268529393839588/02/2027/231",
        "4163650008097526:11:28:021",
    ]
    
    for card_str in test_cards:
        card = parse_card(card_str)
        if card:
            print(f"Parsed: {format_card(card)}")
            print(f"Brand: {get_card_brand(card['number'])}")
            print(f"Luhn: {validate_luhn(card['number'])}")
            print(f"Masked: {mask_card(card['number'])}")
            print("---")
