"""
CC Generator Tool
API: https://drlabapis.onrender.com/api/ccgenerator
"""
import aiohttp
import asyncio
import json
import random

async def generate_cards(bin_number: str, count: int = 10) -> dict:
    """
    Generate credit cards from BIN
    
    Args:
        bin_number: BIN number (6-8 digits)
        count: Number of cards to generate
    
    Returns:
        dict: {'success': bool, 'cards': list, 'bin': str, 'count': int}
    """
    # Validate BIN
    if not bin_number.isdigit() or len(bin_number) < 6:
        return {
            'success': False,
            'error': 'Invalid BIN number (must be at least 6 digits)',
            'cards': [],
            'bin': bin_number,
            'count': 0
        }
    
    # Limit count
    if count > 100:
        count = 100
    elif count < 1:
        count = 1
    
    # API endpoint
    api_url = f"https://drlabapis.onrender.com/api/ccgenerator?bin={bin_number}&count={count}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                api_response = await resp.text()
                
                # Parse JSON response
                try:
                    data = json.loads(api_response)
                except json.JSONDecodeError:
                    # Try to parse as plain text (one card per line)
                    cards = [line.strip() for line in api_response.split('\n') if line.strip()]
                    if cards:
                        return {
                            'success': True,
                            'cards': cards,
                            'bin': bin_number,
                            'count': len(cards)
                        }
                    else:
                        return {
                            'success': False,
                            'error': 'Invalid API response',
                            'cards': [],
                            'bin': bin_number,
                            'count': 0
                        }
                
                # Extract cards
                if isinstance(data, list):
                    cards = data
                elif isinstance(data, dict):
                    cards = data.get('cards', []) or data.get('data', []) or []
                else:
                    cards = []
                
                if cards:
                    return {
                        'success': True,
                        'cards': cards,
                        'bin': bin_number,
                        'count': len(cards)
                    }
                else:
                    return {
                        'success': False,
                        'error': 'No cards generated',
                        'cards': [],
                        'bin': bin_number,
                        'count': 0
                    }
                
    except asyncio.TimeoutError:
        return {
            'success': False,
            'error': 'API request timed out',
            'cards': [],
            'bin': bin_number,
            'count': 0
        }
    except Exception as e:
        return {
            'success': False,
            'error': f'Error: {str(e)}',
            'cards': [],
            'bin': bin_number,
            'count': 0
        }


def generate_random_expiry():
    """Generate random expiry date (MM|YY)"""
    mm = random.randint(1, 12)
    yy = random.randint(25, 30)
    return f"{mm:02d}|{yy}"


def generate_random_cvv():
    """Generate random CVV (3 digits)"""
    return str(random.randint(100, 999))


def format_generated_cards(cards: list, add_expiry: bool = True) -> list:
    """
    Format generated cards with expiry and CVV
    
    Args:
        cards: List of card numbers
        add_expiry: Whether to add expiry and CVV
    
    Returns:
        list: Formatted cards (cc|mm|yy|cvv)
    """
    formatted = []
    
    for card in cards:
        # Remove existing formatting
        card = card.replace('|', '').replace('/', '').replace(' ', '').strip()
        
        if add_expiry:
            # Check if card already has expiry/CVV
            parts = card.split('|')
            if len(parts) == 4:
                # Already formatted
                formatted.append(card)
            elif len(parts) == 1:
                # Add random expiry and CVV
                expiry = generate_random_expiry()
                cvv = generate_random_cvv()
                formatted.append(f"{card}|{expiry}|{cvv}")
            else:
                # Partial format, complete it
                while len(parts) < 4:
                    if len(parts) == 1:
                        expiry = generate_random_expiry()
                        parts.extend(expiry.split('|'))
                    elif len(parts) == 3:
                        parts.append(generate_random_cvv())
                formatted.append('|'.join(parts))
        else:
            formatted.append(card)
    
    return formatted
