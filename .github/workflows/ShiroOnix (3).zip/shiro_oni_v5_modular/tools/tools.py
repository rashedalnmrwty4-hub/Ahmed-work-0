"""
Tools Module for Shiro Oni Chk
- BIN Lookup
- CC Generator
- Filter Tool
- Screenshot Tool
"""
import aiohttp
import asyncio
import json
import random
import re
from typing import Dict, List, Optional

# ==================== BIN LOOKUP ====================

async def bin_lookup(bin_number: str) -> Dict:
    """
    Lookup BIN information
    
    Args:
        bin_number: First 6-8 digits of card
    
    Returns:
        dict: BIN information
    """
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"https://lookup.binlist.net/{bin_number[:6]}",
                timeout=aiohttp.ClientTimeout(total=10)
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return {
                        'success': True,
                        'bin': bin_number[:6],
                        'brand': data.get('scheme', 'Unknown').upper(),
                        'type': data.get('type', 'Unknown').upper(),
                        'level': data.get('brand', 'Unknown').upper(),
                        'bank': data.get('bank', {}).get('name', 'Unknown').upper(),
                        'country': data.get('country', {}).get('name', 'Unknown').upper(),
                        'flag': data.get('country', {}).get('emoji', ''),
                        'currency': data.get('country', {}).get('currency', 'Unknown').upper()
                    }
    except:
        pass
    
    return {
        'success': False,
        'bin': bin_number[:6],
        'error': 'Failed to lookup BIN'
    }

def format_bin_info(bin_data: Dict) -> str:
    """Format BIN information"""
    if not bin_data['success']:
        return f"❌ **BIN Lookup Failed**\n\n{bin_data.get('error', 'Unknown error')}"
    
    return f"""━━━━━━━━━━━━━━━━━━━━━━
**🔍 𝗕𝗜𝗡 𝗟𝗼𝗼𝗸𝘂𝗽 🔍**
━━━━━━━━━━━━━━━━━━━━━━

**𝗕𝗜𝗡** ➜ `{bin_data['bin']}`
**𝗕𝗿𝗮𝗻𝗱** ➜ `{bin_data['brand']}`
**𝗧𝘆𝗽𝗲** ➜ `{bin_data['type']}`
**𝗟𝗲𝘃𝗲𝗹** ➜ `{bin_data['level']}`
**𝗕𝗮𝗻𝗸** ➜ `{bin_data['bank']}`
**𝗖𝗼𝘂𝗻𝘁𝗿𝘆** ➜ `{bin_data['country']} {bin_data['flag']}`
**𝗖𝘂𝗿𝗿𝗲𝗻𝗰𝘆** ➜ `{bin_data['currency']}`

━━━━━━━━━━━━━━━━━━━━━━"""

# ==================== CC GENERATOR ====================

def luhn_checksum(card_number: str) -> int:
    """Calculate Luhn checksum"""
    def digits_of(n):
        return [int(d) for d in str(n)]
    
    digits = digits_of(card_number)
    odd_digits = digits[-1::-2]
    even_digits = digits[-2::-2]
    checksum = sum(odd_digits)
    for d in even_digits:
        checksum += sum(digits_of(d * 2))
    return checksum % 10

def is_luhn_valid(card_number: str) -> bool:
    """Check if card number is Luhn valid"""
    return luhn_checksum(card_number) == 0

def generate_card_number(bin_number: str) -> str:
    """Generate valid card number from BIN"""
    # Remove non-digits
    bin_number = re.sub(r'\D', '', bin_number)
    
    # Ensure BIN is 6-8 digits
    if len(bin_number) < 6:
        bin_number = bin_number.ljust(6, '0')
    
    # Generate random digits to make 15 digits (16th will be checksum)
    remaining_length = 15 - len(bin_number)
    random_digits = ''.join([str(random.randint(0, 9)) for _ in range(remaining_length)])
    
    # Combine BIN + random digits
    card_without_checksum = bin_number + random_digits
    
    # Calculate checksum digit
    checksum = luhn_checksum(card_without_checksum + '0')
    check_digit = (10 - checksum) % 10
    
    return card_without_checksum + str(check_digit)

def generate_expiry() -> tuple:
    """Generate random expiry date"""
    mm = random.randint(1, 12)
    yy = random.randint(25, 30)
    return f"{mm:02d}", str(yy)

def generate_cvv() -> str:
    """Generate random CVV"""
    return str(random.randint(100, 999))

async def generate_cards(bin_number: str, count: int = 10) -> List[str]:
    """
    Generate credit cards from BIN
    
    Args:
        bin_number: BIN number (6-8 digits)
        count: Number of cards to generate
    
    Returns:
        list: Generated cards in format cc|mm|yy|cvv
    """
    # Validate BIN
    bin_number = re.sub(r'\D', '', bin_number)
    if len(bin_number) < 6:
        return []
    
    # Limit count
    count = min(count, 50)  # Max 50 cards
    
    cards = []
    for _ in range(count):
        cc = generate_card_number(bin_number)
        mm, yy = generate_expiry()
        cvv = generate_cvv()
        cards.append(f"{cc}|{mm}|{yy}|{cvv}")
    
    return cards

def format_generated_cards(cards: List[str], bin_number: str) -> str:
    """Format generated cards"""
    if not cards:
        return "❌ **Failed to generate cards!**"
    
    cards_text = '\n'.join([f"`{card}`" for card in cards])
    
    return f"""━━━━━━━━━━━━━━━━━━━━━━
**🎲 𝗖𝗖 𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗼𝗿 🎲**
━━━━━━━━━━━━━━━━━━━━━━

**𝗕𝗜𝗡** ➜ `{bin_number}`
**𝗖𝗼𝘂𝗻𝘁** ➜ `{len(cards)}`

**𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗲𝗱 𝗖𝗮𝗿𝗱𝘀:**
{cards_text}

━━━━━━━━━━━━━━━━━━━━━━"""

# ==================== FILTER TOOL ====================

def extract_cards_from_text(text: str) -> List[str]:
    """Extract all valid cards from text"""
    pattern = r'\d{12,16}\|\d{1,2}\|\d{2,4}\|\d{3,4}'
    return re.findall(pattern, text)

def filter_by_bin(cards: List[str], bin_filter: str) -> List[str]:
    """Filter cards by BIN"""
    bin_filter = re.sub(r'\D', '', bin_filter)
    return [card for card in cards if card.startswith(bin_filter)]

def filter_by_brand(cards: List[str], brand: str) -> List[str]:
    """Filter cards by brand (Visa, Mastercard, etc.)"""
    brand_bins = {
        'visa': ['4'],
        'mastercard': ['51', '52', '53', '54', '55', '2'],
        'amex': ['34', '37'],
        'discover': ['6011', '65'],
        'jcb': ['35']
    }
    
    brand = brand.lower()
    if brand not in brand_bins:
        return cards
    
    prefixes = brand_bins[brand]
    return [card for card in cards if any(card.startswith(p) for p in prefixes)]

def remove_duplicates(cards: List[str]) -> List[str]:
    """Remove duplicate cards"""
    return list(dict.fromkeys(cards))

def format_filtered_cards(cards: List[str], filter_type: str, filter_value: str) -> str:
    """Format filtered cards"""
    if not cards:
        return f"❌ **No cards found matching filter:** `{filter_value}`"
    
    # Limit display to 50 cards
    display_cards = cards[:50]
    cards_text = '\n'.join([f"`{card}`" for card in display_cards])
    
    more_text = f"\n\n**... and {len(cards) - 50} more cards**" if len(cards) > 50 else ""
    
    return f"""━━━━━━━━━━━━━━━━━━━━━━
**🔍 𝗙𝗶𝗹𝘁𝗲𝗿 𝗥𝗲𝘀𝘂𝗹𝘁𝘀 🔍**
━━━━━━━━━━━━━━━━━━━━━━

**𝗙𝗶𝗹𝘁𝗲𝗿** ➜ `{filter_type}: {filter_value}`
**𝗧𝗼𝘁𝗮𝗹** ➜ `{len(cards)} cards`

**𝗙𝗶𝗹𝘁𝗲𝗿𝗲𝗱 𝗖𝗮𝗿𝗱𝘀:**
{cards_text}{more_text}

━━━━━━━━━━━━━━━━━━━━━━"""

# ==================== SCREENSHOT TOOL ====================

async def capture_screenshot(url: str, api_key: str = "911fbd00141a44ea91830d7d81945840") -> Dict:
    """
    Capture website screenshot
    
    Args:
        url: Website URL
        api_key: APIFlash API key
    
    Returns:
        dict: {'success': bool, 'image_url': str, 'error': str}
    """
    # Validate URL
    if not url.startswith('http'):
        url = f'https://{url}'
    
    # API endpoint
    api_url = (
        f"https://api.apiflash.com/v1/urltoimage"
        f"?access_key={api_key}"
        f"&wait_until=page_loaded"
        f"&url={url}"
    )
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                timeout=aiohttp.ClientTimeout(total=60)
            ) as resp:
                if resp.status == 200:
                    image_data = await resp.read()
                    return {
                        'success': True,
                        'image_data': image_data,
                        'image_url': api_url,
                        'size': len(image_data),
                        'url': url
                    }
                else:
                    error_text = await resp.text()
                    return {
                        'success': False,
                        'error': f'HTTP {resp.status}: {error_text[:200]}',
                        'url': url
                    }
    except asyncio.TimeoutError:
        return {
            'success': False,
            'error': 'Screenshot request timed out',
            'url': url
        }
    except Exception as e:
        return {
            'success': False,
            'error': f'Error: {str(e)}',
            'url': url
        }

# ==================== BIN MANIPULATION ====================

def extract_bin_from_card(card: str) -> str:
    """Extract BIN from card"""
    # Remove non-digits
    card = re.sub(r'\D', '', card)
    return card[:6] if len(card) >= 6 else card

def get_card_brand(bin_number: str) -> str:
    """Get card brand from BIN"""
    bin_number = re.sub(r'\D', '', bin_number)
    
    if bin_number.startswith('4'):
        return 'VISA'
    elif bin_number[:2] in ['51', '52', '53', '54', '55'] or bin_number.startswith('2'):
        return 'MASTERCARD'
    elif bin_number[:2] in ['34', '37']:
        return 'AMERICAN EXPRESS'
    elif bin_number.startswith('6011') or bin_number.startswith('65'):
        return 'DISCOVER'
    elif bin_number.startswith('35'):
        return 'JCB'
    else:
        return 'UNKNOWN'

def format_bin_manipulation(cards: List[str], operation: str) -> str:
    """Format BIN manipulation results"""
    if not cards:
        return "❌ **No cards provided!**"
    
    results = []
    for card in cards[:20]:  # Limit to 20
        bin_num = extract_bin_from_card(card)
        brand = get_card_brand(bin_num)
        results.append(f"`{bin_num}` - {brand}")
    
    results_text = '\n'.join(results)
    more_text = f"\n\n**... and {len(cards) - 20} more**" if len(cards) > 20 else ""
    
    return f"""━━━━━━━━━━━━━━━━━━━━━━
**🔧 𝗕𝗜𝗡 𝗠𝗮𝗻𝗶𝗽𝘂𝗹𝗮𝘁𝗶𝗼𝗻 🔧**
━━━━━━━━━━━━━━━━━━━━━━

**𝗢𝗽𝗲𝗿𝗮𝘁𝗶𝗼𝗻** ➜ `{operation}`
**𝗧𝗼𝘁𝗮𝗹** ➜ `{len(cards)} cards`

**𝗥𝗲𝘀𝘂𝗹𝘁𝘀:**
{results_text}{more_text}

━━━━━━━━━━━━━━━━━━━━━━"""
