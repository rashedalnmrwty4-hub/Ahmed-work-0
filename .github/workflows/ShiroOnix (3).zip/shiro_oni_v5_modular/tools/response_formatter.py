"""
Response Formatter - Professional response formatting for Shiro Oni Chk V2
"""
import html
from config import *

def format_status(status_text: str) -> tuple:
    """
    Format status text with appropriate emoji
    Returns: (emoji_status, clean_status)
    """
    status_lower = status_text.lower()
    
    # Approved cases
    if "approved" in status_lower or "succeeded" in status_lower:
        return f"{STATUS_APPROVED} APPROVED", "APPROVED"
    
    # CCN Live (Incorrect CVC, Insufficient Funds, etc.)
    if "ccn live" in status_lower:
        return f"{STATUS_CCN_LIVE} CCN LIVE", "CCN LIVE"
    
    if "incorrect_cvc" in status_lower or "incorrect cvc" in status_lower:
        return f"{STATUS_CCN_LIVE} CCN LIVE", "CCN LIVE"
    
    if "insufficient funds" in status_lower or "insufficient_funds" in status_lower:
        return f"{STATUS_INSUFFICIENT} INSUFFICIENT FUNDS", "CCN LIVE"
    
    # 3DS / Authentication
    if "3ds" in status_lower or "auth required" in status_lower or "authentication" in status_lower:
        return f"{STATUS_3DS} 3DS REQUIRED", "CCN LIVE"
    
    # Expired
    if "expired" in status_lower:
        return f"{STATUS_EXPIRED} EXPIRED", "DECLINED"
    
    # Stolen/Lost
    if "stolen" in status_lower:
        return f"{STATUS_STOLEN} STOLEN CARD", "DECLINED"
    
    if "lost" in status_lower:
        return f"{STATUS_STOLEN} LOST CARD", "DECLINED"
    
    if "pickup" in status_lower:
        return f"{STATUS_PICKUP} PICKUP CARD", "DECLINED"
    
    # Fraud
    if "fraud" in status_lower:
        return f"{STATUS_FRAUD} FRAUDULENT", "DECLINED"
    
    # Declined
    if "declined" in status_lower or "do not honor" in status_lower:
        return f"{STATUS_DECLINED} DECLINED", "DECLINED"
    
    # Incorrect number
    if "incorrect" in status_lower and "number" in status_lower:
        return f"{STATUS_DECLINED} INCORRECT NUMBER", "DECLINED"
    
    # Default
    return f"{STATUS_UNKNOWN} {status_text.upper()}", "UNKNOWN"


def format_card_response(
    card: str,
    gateway: str,
    status: str,
    response: str,
    bin_info: dict,
    elapsed_time: float,
    user_id: int,
    username: str = None,
    amount: float = 0.00
) -> str:
    """
    Format single card check response in gatesbot style
    
    Args:
        card: Card number in format cc|mm|yy|cvv
        gateway: Gateway name
        status: Status from API
        response: Response message from API
        bin_info: BIN information dict
        elapsed_time: Time taken for check
        user_id: User's Telegram ID
        username: User's username (optional)
        amount: Gateway charge amount
    
    Returns:
        Formatted HTML response string
    """
    # Format status
    status_display, status_type = format_status(status)
    
    # Parse card
    parts = card.split('|')
    if len(parts) >= 4:
        cc, mm, yy, cvv = parts[0], parts[1], parts[2], parts[3]
        # Format card with spaces
        cc_formatted = f"{cc[:4]} {cc[4:8]} {cc[8:12]} {cc[12:]}" if len(cc) == 16 else cc
        card_display = f"{cc_formatted}|{mm}|{yy}|{cvv}"
    else:
        card_display = card
    
    # BIN info
    brand = bin_info.get('scheme', 'N/A').title()
    issuer = bin_info.get('bank', 'N/A')
    country = bin_info.get('country', 'N/A')
    country_flag = bin_info.get('country_emoji', '')
    card_type = bin_info.get('type', 'N/A').title()
    
    # Clickable bullet
    bullet_link = f"<a href='{BULLET_GROUP_LINK}'>[{BULLET}]</a>"
    bullet_arrow = f"<a href='{BULLET_GROUP_LINK}'>{BULLET_ARROW}</a>"
    
    # User info
    requester = f'<a href="tg://user?id={user_id}">{html.escape(username or "User")}</a>'
    
    # Amount display
    if amount > 0:
        amount_display = f"${amount:.2f}" if amount < 100 else f"₹{amount:.0f}"
    else:
        amount_display = "Free"
    
    # Build response
    response_text = (
        f"<b><i>{status_display}</i></b>\n\n"
        f"{bullet_link} 𝐂𝐚𝐫𝐝\n"
        f"⤷ <code>{html.escape(card_display)}</code>\n"
        f"{bullet_link} 𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ➵ {to_bold(gateway)}\n"
        f"{bullet_link} 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞 ➵ <b><code>{html.escape(response)}</code></b>\n\n"
        f"<pre>"
        f"𝐁𝐫𝐚𝐧𝐝 ➵ {html.escape(brand)}\n"
        f"𝐁𝐚𝐧𝐤 ➵ {html.escape(issuer)}\n"
        f"𝐂𝐨𝐮𝐧𝐭𝐫𝐲 ➵ {html.escape(country)} {html.escape(country_flag)}\n"
        f"𝐓𝐲𝐩𝐞 ➵ {html.escape(card_type)}"
        f"</pre>\n\n"
        f"{bullet_arrow} 𝐔𝐬𝐞𝐫 ➵ {requester}\n"
        f"{bullet_arrow} 𝐀𝐦𝐨𝐮𝐧𝐭 ➵ {amount_display}\n"
        f"{bullet_arrow} 𝐃𝐄𝐕 ➵ <a href='{DEVELOPER_LINK}'>{DEVELOPER}</a>\n"
        f"{bullet_arrow} 𝐄𝐥𝐚𝐩𝐬𝐞𝐝 ➵ {elapsed_time:.2f}s"
    )
    
    return response_text


def format_mass_check_result(
    gateway: str,
    total: int,
    approved: int,
    declined: int,
    elapsed_time: float,
    user_id: int,
    username: str = None
) -> str:
    """
    Format mass check summary
    """
    success_rate = (approved / total * 100) if total > 0 else 0
    avg_time = elapsed_time / total if total > 0 else 0
    
    bullet_link = f"<a href='{BULLET_GROUP_LINK}'>[{BULLET}]</a>"
    requester = f'<a href="tg://user?id={user_id}">{html.escape(username or "User")}</a>'
    
    response_text = (
        f"✦━━━━━━━━━━━━━━✦\n"
        f"<b><i>𝐌𝐀𝐒𝐒 𝐂𝐇𝐄𝐂𝐊 𝐂𝐎𝐌𝐏𝐋𝐄𝐓𝐄</i></b>\n"
        f"✦━━━━━━━━━━━━━━✦\n\n"
        f"{bullet_link} 𝐆𝐚𝐭𝐞𝐰𝐚𝐲 ➵ {to_bold(gateway)}\n"
        f"{bullet_link} 𝐓𝐨𝐭𝐚𝐥 ➵ <code>{total}</code>\n\n"
        f"⇨ 𝐑𝐞𝐬𝐮𝐥𝐭𝐬:\n"
        f"├ {STATUS_APPROVED} 𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝: <code>{approved}</code>\n"
        f"├ {STATUS_DECLINED} 𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝: <code>{declined}</code>\n"
        f"└ 📊 𝐒𝐮𝐜𝐜𝐞𝐬𝐬 𝐑𝐚𝐭𝐞: <code>{success_rate:.1f}%</code>\n\n"
        f"⏱️ 𝐓𝐨𝐭𝐚𝐥 𝐓𝐢𝐦𝐞: <code>{elapsed_time:.2f}s</code>\n"
        f"⚡ 𝐀𝐯𝐠 𝐓𝐢𝐦𝐞: <code>{avg_time:.2f}s</code> per card\n\n"
        f"{SEPARATOR_FANCY}\n"
        f"𝐔𝐬𝐞𝐫: {requester}\n"
        f"𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 {BOT_NAME} {BOT_VERSION}"
    )
    
    return response_text


def format_bin_info(bin_info: dict, bin_number: str) -> str:
    """
    Format BIN lookup response
    """
    if 'error' in bin_info:
        return f"❌ {bin_info['error']}"
    
    bullet_link = f"<a href='{BULLET_GROUP_LINK}'>[{BULLET}]</a>"
    
    response_text = (
        f"✦━━━━━━━━━━━━━━✦\n"
        f"<b><i>𝐁𝐈𝐍 𝐋𝐎𝐎𝐊𝐔𝐏</i></b>\n"
        f"✦━━━━━━━━━━━━━━✦\n\n"
        f"{bullet_link} 𝐁𝐈𝐍 ➵ <code>{bin_number}</code>\n"
        f"{bullet_link} 𝐁𝐫𝐚𝐧𝐝 ➵ {bin_info.get('scheme', 'N/A').title()}\n"
        f"{bullet_link} 𝐓𝐲𝐩𝐞 ➵ {bin_info.get('type', 'N/A').title()}\n"
        f"{bullet_link} 𝐋𝐞𝐯𝐞𝐥 ➵ {bin_info.get('brand', 'N/A').title()}\n"
        f"{bullet_link} 𝐁𝐚𝐧𝐤 ➵ {bin_info.get('bank', 'N/A')}\n"
        f"{bullet_link} 𝐂𝐨𝐮𝐧𝐭𝐫𝐲 ➵ {bin_info.get('country', 'N/A')} {bin_info.get('country_emoji', '')}\n\n"
        f"{SEPARATOR_FANCY}\n"
        f"𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 {BOT_NAME}"
    )
    
    return response_text


def format_error_message(error_msg: str) -> str:
    """Format error message"""
    return (
        f"❌ <b>Error</b>\n\n"
        f"<code>{html.escape(error_msg)}</code>\n\n"
        f"Please try again or contact {DEVELOPER}"
    )
