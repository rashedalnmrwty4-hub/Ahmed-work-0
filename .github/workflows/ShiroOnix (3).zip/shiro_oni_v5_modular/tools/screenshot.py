"""
Website Screenshot Tool
API: https://api.apiflash.com/v1/urltoimage
"""
import aiohttp
import asyncio

async def capture_screenshot(url: str, access_key: str = "911fbd00141a44ea91830d7d81945840") -> dict:
    """
    Capture website screenshot
    
    Args:
        url: Website URL to capture
        access_key: APIFlash access key
    
    Returns:
        dict: {'success': bool, 'image_url': str, 'error': str}
    """
    # Validate URL
    if not url.startswith('http'):
        url = f'https://{url}'
    
    # API endpoint
    api_url = (
        f"https://api.apiflash.com/v1/urltoimage"
        f"?access_key={access_key}"
        f"&wait_until=page_loaded"
        f"&url={url}"
    )
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                timeout=aiohttp.ClientTimeout(total=60)
            ) as resp:
                if resp.status == 200:
                    # Get image data
                    image_data = await resp.read()
                    
                    return {
                        'success': True,
                        'image_url': api_url,
                        'image_data': image_data,
                        'size': len(image_data),
                        'url': url
                    }
                else:
                    error_text = await resp.text()
                    return {
                        'success': False,
                        'error': f'HTTP {resp.status}: {error_text[:200]}',
                        'image_url': None,
                        'url': url
                    }
                
    except asyncio.TimeoutError:
        return {
            'success': False,
            'error': 'Screenshot request timed out',
            'image_url': None,
            'url': url
        }
    except Exception as e:
        return {
            'success': False,
            'error': f'Error: {str(e)}',
            'image_url': None,
            'url': url
        }


async def save_screenshot(url: str, output_path: str, access_key: str = "911fbd00141a44ea91830d7d81945840") -> bool:
    """
    Capture and save screenshot to file
    
    Args:
        url: Website URL
        output_path: Path to save image
        access_key: APIFlash access key
    
    Returns:
        bool: Success status
    """
    result = await capture_screenshot(url, access_key)
    
    if result['success']:
        try:
            with open(output_path, 'wb') as f:
                f.write(result['image_data'])
            return True
        except Exception as e:
            print(f"Error saving screenshot: {e}")
            return False
    else:
        print(f"Screenshot failed: {result['error']}")
        return False
