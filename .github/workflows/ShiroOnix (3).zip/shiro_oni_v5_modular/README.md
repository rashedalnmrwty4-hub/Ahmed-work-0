# Shiro Oni Chk V5.0.0 Modular

Professional CC Checker Bot with modular architecture

## Features

- ✅ 51+ Working Gateways (Auto-loaded)
- ✅ 6 Tools (BIN, Gen, Filter, Screenshot, etc.)
- ✅ Ex Bot Style UI
- ✅ Response Parser (No JSON in messages)
- ✅ Site Management System
- ✅ Mass Check (10 cards limit)
- ✅ TXT File Handler
- ✅ Modular Architecture

## Installation

```bash
# Clone
git clone https://github.com/bdtgffavvbCcXxdUkBhai/Diwas.git
cd Diwas

# Install
pip3 install -r requirements.txt

# Run
python3 bot.py
```

## Structure

```
shiro_oni_v5_modular/
├── bot.py                    # Main bot file
├── config.py                 # Configuration
├── requirements.txt          # Dependencies
├── handlers/                 # All handlers
│   ├── gateway_handler.py    # Gateway logic
│   ├── tool_handler.py       # Tool logic
│   ├── ui_handler.py         # UI logic
│   └── command_handler.py    # Command routing
├── gates/                    # 51+ gateways
├── tools/                    # All tools
└── utils/                    # Utilities
    ├── response_parser.py    # Response parsing
    ├── card_parser.py        # Card parsing
    └── helpers.py            # Helper functions
```

## Configuration

Edit `config.py`:
- BOT_TOKEN
- API_ID / API_HASH
- OWNER_ID / OWNER_USERNAME

## Commands

**Gateways:**
- `/st` - Stripe $1
- `/s4` - Stripe $4
- `/sh` - AutoShopify
- `/rz1` - Razorpay ₹1
- And 40+ more...

**Tools:**
- `/bin <bin>` - BIN Lookup
- `/gen <bin> [count]` - CC Generator
- `/filter <type> <value>` - Filter Tool
- `/ss <url>` - Screenshot
- `/binex` - BIN Extraction
- `/info` - User Info

**Site Management:**
- `/seturl <url>` - Add site
- `/vurl` - View sites
- `/rmurl [url]` - Remove site

**Mass Check:**
- `/masssh` - Mass Shopify
- `/massrz` - Mass Razorpay
- Upload .txt file with cards

## Owner

- Owner: @diwasxd (8409885560)
- Bot: Shiro Oni Chk v5.0.0 Modular
- Status: Production Ready 🔥

## License

Private - For authorized use only
