"""
PayPal Gateway - Using actual working API
"""
import aiohttp
import asyncio
import json

async def paypal_check(cc: str, mm: str, yy: str, cvv: str) -> dict:
    """
    PayPal $1 charge using real API endpoint
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
    
    Returns:
        dict: {'status': str, 'response': str, 'message': str, 'details': str}
    """
    # Format card
    payload = f"{cc}|{mm}|{yy}|{cvv}"
    
    # API endpoint from gatesbot
    api_url = f"https://paypal-blaze-larh.onrender.com/gateway=pp/cc={payload}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=aiohttp.ClientTimeout(total=90)
            ) as resp:
                api_response_text = await resp.text()
                
                # Parse JSON response
                try:
                    data = json.loads(api_response_text)
                except json.JSONDecodeError:
                    return {
                        'status': 'Unknown',
                        'response': 'Invalid API Response',
                        'message': 'Invalid Response',
                        'details': api_response_text[:200]
                    }
                
                # Extract data
                status = data.get("status", "unknown")
                message = data.get("message", "Unknown")
                details = data.get("details", "")
                elapsed = data.get("elapsed", "")
                
                # Clean response text
                cleaned_response = details
                if isinstance(details, str) and ":" in details:
                    cleaned_response = details.split(":", 1)[1].strip()
                
                # Map status
                if status == "Charged 🔥":
                    final_status = "Approved"
                elif status == "declined":
                    final_status = "Declined"
                elif status == "error":
                    final_status = "Unknown"
                else:
                    final_status = status
                
                return {
                    'status': final_status,
                    'response': cleaned_response or message,
                    'message': message,
                    'details': details,
                    'elapsed': elapsed
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Unknown',
            'response': 'API request timed out',
            'message': 'Timeout',
            'details': 'Request timeout after 90s'
        }
    except Exception as e:
        return {
            'status': 'Unknown',
            'response': f'API request failed: {str(e)}',
            'message': 'Error',
            'details': str(e)
        }
