"""
Configuration for Shiro Oni Chk V5
"""

# Bot Configuration
BOT_TOKEN = "7833872635:AAE93aKO6Yggic72JLZuu_jpgDuqUJiA6sc"
API_ID = 31227412
API_HASH = "e012542d5ebbbcb8e3e358b4e5089b99"

# Owner Configuration
OWNER_ID = 8409885560
OWNER_USERNAME = "@diwasxd"

# Bot Information
BOT_NAME = "Shiro Oni Chk"
BOT_VERSION = "v5.0.0 Modular"
BOT_DESCRIPTION = "Professional CC Checker Bot"

# Limits
MASS_CHECK_LIMIT = 10
TXT_FILE_LIMIT = 10
API_TIMEOUT = 180  # 3 minutes

# Data Files
USER_SITES_FILE = "data/user_sites.json"
APPROVED_CARDS_FILE = "data/approved_cards.txt"
STATS_FILE = "data/stats.json"
USERS_FILE = "data/users.json"

# Default Proxy for AutoShopify
DEFAULT_PROXY = "proxy-eu.proxy-cheap.com:5959:pcCZ4lcMkp-res-any:PC_0pPzVZIOkgM9ao2Lh"

# BIN Lookup API
BIN_API_URL = "https://bins.antipublic.cc/bins/{}"

# CC Generator API
CC_GEN_API_URL = "https://drlabapis.onrender.com/api/ccgenerator"

# Screenshot API
SCREENSHOT_API_URL = "https://api.apiflash.com/v1/urltoimage"
SCREENSHOT_API_KEY = "911fbd00141a44ea91830d7d81945840"

# Gateway Categories
GATEWAY_CATEGORIES = {
    "auth": ["stripe_auth", "braintree_auth", "woostripe_auth", "checkout_auth", "amex_auth", "adespresso_auth", "pariyatti_auth", "stripe_auth_v2"],
    "charge": ["stripe", "stripe_20", "stripe_4dollar", "stripe_4dollar_v2", "braintree", "paypal_charge", "shopify_auto", "woostripe", "checkout", "madystripe"],
    "ccn": ["stripe_ccn"],
    "vbv": ["vbv_lookup", "vbv2"],
    "killer": ["killer", "killer1", "killer2"],
    "special": ["autoshopify", "razorpay", "authnet1", "authnet_charge", "adyen1"]
}

# Gateway Prices
GATEWAY_PRICES = {
    "stripe": "$1",
    "stripe_20": "$20",
    "stripe_4dollar": "$4",
    "stripe_4dollar_v2": "$4",
    "stripe_auth": "Free",
    "stripe_auth_v2": "Free",
    "braintree": "$1",
    "braintree_auth": "Free",
    "paypal_charge": "$5",
    "paypal1": "$1",
    "paypal3": "$3",
    "shopify_auto": "$0.98",
    "autoshopify": "$0.98",
    "woostripe": "$12",
    "woostripe_auth": "Free",
    "checkout": "$20",
    "checkout_auth": "Free",
    "razorpay": "₹1/₹3/₹5",
    "authnet1": "$1",
    "authnet_charge": "$5",
    "adyen1": "$1",
    "madystripe": "$15",
    "killer": "Killer",
    "killer1": "$1",
    "killer2": "$2",
    "vbv_lookup": "Free",
    "vbv2": "Free",
    "stripe_square": "$0.2",
}

# Gateway Commands
GATEWAY_COMMANDS = {
    # Stripe
    "st": "stripe",
    "s20": "stripe_20",
    "s4": "stripe_4dollar",
    "s4v2": "stripe_4dollar_v2",
    "sa": "stripe_auth",
    "sa2": "stripe_auth_v2",
    "spi": "stripe_payment_intent",
    "sc": "stripe_charge",
    "sccn": "stripe_ccn",
    "sq": "stripe_square",
    
    # Braintree
    "bt": "braintree",
    "ba": "braintree_auth",
    
    # PayPal
    "pp": "paypal_charge",
    "pp1": "paypal1",
    "pp3": "paypal3",
    
    # Shopify
    "sh": "autoshopify",
    "shn": "shopify_nano",
    "sha": "shopify_auto",
    
    # WooStripe
    "ws": "woostripe",
    "wsa": "woostripe_auth",
    
    # Checkout
    "co": "checkout",
    "coa": "checkout_auth",
    
    # Razorpay
    "rz1": "razorpay_1",
    "rz3": "razorpay_3",
    "rz5": "razorpay_5",
    
    # Authorize.net
    "an1": "authnet1",
    "anc": "authnet_charge",
    
    # Adyen
    "ad1": "adyen1",
    
    # Killer
    "kill": "killer",
    "k1": "killer1",
    "k2": "killer2",
    
    # VBV
    "vbv": "vbv_lookup",
    "vbv2": "vbv2",
    
    # Others
    "mady": "madystripe",
    "amex": "amex_auth",
}

# Tool Commands
TOOL_COMMANDS = {
    "bin": "BIN Lookup",
    "gen": "CC Generator",
    "filter": "Filter Tool",
    "ss": "Screenshot",
    "binex": "BIN Extraction",
    "info": "User Info",
}

# Anime Image URL for start message
START_IMAGE_URL = "https://i.imgur.com/8X9Zq0M.jpg"

print("✅ Configuration loaded successfully!")
print(f"Bot: {BOT_NAME} {BOT_VERSION}")
print(f"Owner: {OWNER_USERNAME} ({OWNER_ID})")

# Authorization System
AUTHORIZED_USERS_FILE = "data/authorized_users.json"
REQUIRE_AUTH = True  # Set to False to allow all users

