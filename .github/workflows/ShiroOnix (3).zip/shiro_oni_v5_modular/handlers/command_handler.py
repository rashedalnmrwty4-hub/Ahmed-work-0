"""
Command Handler - Routes commands to appropriate handlers
"""

import config
from handlers import gateway_handler, tool_handler, ui_handler
from utils.card_parser import parse_cards_from_text
from utils.helpers import load_json, save_json

async def handle_start_command(user_id: int, user_stats: dict):
    """
    Handle /start command
    """
    
    message = ui_handler.get_start_message(user_id, user_stats)
    buttons = ui_handler.get_start_buttons()
    image_url = config.START_IMAGE_URL
    
    return {
        'type': 'start',
        'message': message,
        'buttons': buttons,
        'image_url': image_url
    }


async def handle_gateway_command(command: str, args: str, user_id: int):
    """
    Handle gateway commands
    """
    
    # Get gateway name from command
    gateway_name = config.GATEWAY_COMMANDS.get(command)
    
    if not gateway_name:
        return {
            'type': 'error',
            'message': f"❌ Unknown command: /{command}"
        }
    
    # Parse card from args
    if not args:
        return {
            'type': 'error',
            'message': f"❌ Usage: /{command} cc|mm|yy|cvv"
        }
    
    # Get processing message
    processing_msg = ui_handler.get_processing_message(gateway_name.replace('_', ' ').title())
    
    # Check card
    result = await gateway_handler.check_card_with_gateway(args, gateway_name, user_id)
    
    return {
        'type': 'gateway_result',
        'processing_message': processing_msg,
        'result': result
    }


async def handle_mass_command(command: str, cards_text: str, user_id: int):
    """
    Handle mass check commands
    """
    
    # Extract gateway name from command (e.g., masssh -> sh)
    gateway_cmd = command.replace('mass', '')
    gateway_name = config.GATEWAY_COMMANDS.get(gateway_cmd)
    
    if not gateway_name:
        return {
            'type': 'error',
            'message': f"❌ Unknown mass command: /{command}"
        }
    
    # Parse cards
    cards = parse_cards_from_text(cards_text, config.MASS_CHECK_LIMIT)
    
    if not cards:
        return {
            'type': 'error',
            'message': f"❌ No valid cards found. Use format: cc|mm|yy|cvv"
        }
    
    return {
        'type': 'mass_check',
        'gateway_name': gateway_name,
        'cards': [f"{c['number']}|{c['exp_month']}|{c['exp_year']}|{c['cvc']}" for c in cards]
    }


async def handle_tool_command(command: str, args: str, user_id: int, **kwargs):
    """
    Handle tool commands
    """
    
    if command == 'bin':
        if not args or len(args) < 6:
            return {
                'type': 'error',
                'message': "❌ Usage: /bin <bin_number>"
            }
        
        result = await tool_handler.bin_lookup(args[:6])
        
        return {
            'type': 'tool_result',
            'result': result
        }
    
    elif command == 'gen':
        parts = args.split()
        bin_number = parts[0] if parts else None
        count = int(parts[1]) if len(parts) > 1 else 10
        
        if not bin_number or len(bin_number) < 6:
            return {
                'type': 'error',
                'message': "❌ Usage: /gen <bin> [count]"
            }
        
        result = await tool_handler.cc_generator(bin_number[:6], count)
        
        return {
            'type': 'tool_result',
            'result': result
        }
    
    elif command == 'ss':
        if not args:
            return {
                'type': 'error',
                'message': "❌ Usage: /ss <url>"
            }
        
        result = await tool_handler.screenshot_tool(args)
        
        return {
            'type': 'screenshot_result',
            'result': result
        }
    
    elif command == 'filter':
        parts = args.split(maxsplit=1)
        filter_type = parts[0] if parts else None
        filter_value = parts[1] if len(parts) > 1 else None
        
        cards = kwargs.get('cards', [])
        
        if not filter_type:
            return {
                'type': 'error',
                'message': "❌ Usage: /filter <type> <value>\nTypes: bin, brand, unique"
            }
        
        result = await tool_handler.filter_tool(filter_type, filter_value or '', cards)
        
        return {
            'type': 'tool_result',
            'result': result
        }
    
    elif command == 'binex':
        cards = kwargs.get('cards', [])
        
        if not cards:
            return {
                'type': 'error',
                'message': "❌ Reply to a message with cards"
            }
        
        result = await tool_handler.bin_extraction(cards)
        
        return {
            'type': 'tool_result',
            'result': result
        }
    
    elif command == 'info':
        result = await tool_handler.user_info_tool(user_id)
        
        return {
            'type': 'tool_result',
            'result': result
        }
    
    else:
        return {
            'type': 'error',
            'message': f"❌ Unknown tool command: /{command}"
        }


async def handle_site_command(command: str, args: str, user_id: int):
    """
    Handle site management commands
    """
    
    sites = await load_json(config.USER_SITES_FILE)
    user_sites = sites.get(str(user_id), [])
    
    if command == 'seturl':
        if not args:
            return {
                'type': 'error',
                'message': "❌ Usage: /seturl <url>"
            }
        
        if args not in user_sites:
            user_sites.append(args)
            sites[str(user_id)] = user_sites
            await save_json(config.USER_SITES_FILE, sites)
        
        return {
            'type': 'success',
            'message': f"✅ Site added: {args}"
        }
    
    elif command == 'vurl':
        if not user_sites:
            return {
                'type': 'error',
                'message': "❌ No sites found. Use /seturl to add a site."
            }
        
        message = "🏪 Your Sites:\n\n"
        for i, site in enumerate(user_sites, 1):
            message += f"{i}. {site}\n"
        
        return {
            'type': 'success',
            'message': message
        }
    
    elif command == 'rmurl':
        if not args:
            # Remove all sites
            sites[str(user_id)] = []
            await save_json(config.USER_SITES_FILE, sites)
            
            return {
                'type': 'success',
                'message': "✅ All sites removed"
            }
        else:
            # Remove specific site
            if args in user_sites:
                user_sites.remove(args)
                sites[str(user_id)] = user_sites
                await save_json(config.USER_SITES_FILE, sites)
                
                return {
                    'type': 'success',
                    'message': f"✅ Site removed: {args}"
                }
            else:
                return {
                    'type': 'error',
                    'message': f"❌ Site not found: {args}"
                }
    
    else:
        return {
            'type': 'error',
            'message': f"❌ Unknown site command: /{command}"
        }


async def handle_button_callback(callback_data: str, user_id: int):
    """
    Handle inline button callbacks
    """
    
    if callback_data == 'menu_home':
        user_stats = await tool_handler.get_user_stats(user_id)
        return await handle_start_command(user_id, user_stats)
    
    elif callback_data == 'menu_gates':
        return {
            'type': 'menu',
            'message': ui_handler.get_gates_menu_message(),
            'buttons': [[Button.inline("🏠 HOME", b"menu_home")]]
        }
    
    elif callback_data == 'menu_tools':
        return {
            'type': 'menu',
            'message': ui_handler.get_tools_menu_message(),
            'buttons': [[Button.inline("🏠 HOME", b"menu_home")]]
        }
    
    elif callback_data == 'menu_selfshop':
        return {
            'type': 'menu',
            'message': ui_handler.get_selfshop_menu_message(),
            'buttons': [[Button.inline("🏠 HOME", b"menu_home")]]
        }
    
    elif callback_data == 'menu_close':
        return {
            'type': 'close',
            'message': "❌ Closed"
        }
    
    else:
        return {
            'type': 'error',
            'message': "❌ Unknown callback"
        }


# Test
if __name__ == '__main__':
    print("Command handler loaded")
    print(f"Gateway commands: {len(config.GATEWAY_COMMANDS)}")
    print(f"Tool commands: {len(config.TOOL_COMMANDS)}")
