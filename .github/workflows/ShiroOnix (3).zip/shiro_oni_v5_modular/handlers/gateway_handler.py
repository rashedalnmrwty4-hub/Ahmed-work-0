"""
Gateway Handler - Automatically loads and handles all gateways
"""

import importlib
import os
import time
import asyncio
import aiohttp
from typing import Dict, Optional

import config
from utils.card_parser import parse_card, format_card
from utils.response_parser import parse_response, format_response_for_telegram
from utils.helpers import log_approved_card, update_user_stats

# Gateway function cache
_gateway_cache = {}

def load_gateway(gateway_name: str):
    """
    Dynamically load gateway module
    """
    
    if gateway_name in _gateway_cache:
        return _gateway_cache[gateway_name]
    
    try:
        # Try to import gateway module
        module = importlib.import_module(f"gates.{gateway_name}")
        
        # Look for check_card function
        if hasattr(module, 'check_card'):
            _gateway_cache[gateway_name] = module.check_card
            return module.check_card
        
        return None
    except Exception as e:
        print(f"Error loading gateway {gateway_name}: {e}")
        return None


async def check_card_with_gateway(card_string: str, gateway_name: str, user_id: int, **kwargs) -> Dict:
    """
    Check card using specified gateway
    
    Returns:
        dict: {status, message, response_time, formatted_response}
    """
    
    start_time = time.time()
    
    try:
        # Parse card
        card = parse_card(card_string)
        if not card:
            return {
                'status': 'Error',
                'message': 'Invalid card format. Use: cc|mm|yy|cvv',
                'response_time': 0,
                'formatted_response': None
            }
        
        # Load gateway function
        gateway_func = load_gateway(gateway_name)
        
        if not gateway_func:
            return {
                'status': 'Error',
                'message': f'Gateway {gateway_name} not found',
                'response_time': 0,
                'formatted_response': None
            }
        
        # Check if async or sync
        if asyncio.iscoroutinefunction(gateway_func):
            result = await asyncio.wait_for(
                gateway_func(card, **kwargs),
                timeout=config.API_TIMEOUT
            )
        else:
            # Run sync function in executor
            loop = asyncio.get_event_loop()
            result = await asyncio.wait_for(
                loop.run_in_executor(None, gateway_func, card, **kwargs),
                timeout=config.API_TIMEOUT
            )
        
        response_time = time.time() - start_time
        
        # Parse response
        parsed = parse_response(result, gateway_name)
        
        # Get BIN info
        bin_info = await get_bin_info(card['number'][:6])
        
        # Format for Telegram
        formatted = format_response_for_telegram(
            card=format_card(card),
            status=parsed['status'],
            message=parsed['message'],
            gateway=gateway_name.replace('_', ' ').title(),
            price=config.GATEWAY_PRICES.get(gateway_name, 'Unknown'),
            bin_info=bin_info,
            time_taken=response_time
        )
        
        # Update stats
        await update_user_stats(user_id, parsed['status'])
        
        # Log if approved
        if parsed['status'].lower() in ['charged', 'approved']:
            await log_approved_card(format_card(card), gateway_name)
        
        return {
            'status': parsed['status'],
            'message': parsed['message'],
            'response_time': response_time,
            'formatted_response': formatted
        }
        
    except asyncio.TimeoutError:
        response_time = time.time() - start_time
        
        # Return fake declined response on timeout
        bin_info = await get_bin_info(card['number'][:6]) if card else {}
        
        formatted = format_response_for_telegram(
            card=card_string,
            status='Declined',
            message='Request timeout',
            gateway=gateway_name.replace('_', ' ').title(),
            price=config.GATEWAY_PRICES.get(gateway_name, 'Unknown'),
            bin_info=bin_info,
            time_taken=response_time
        )
        
        await update_user_stats(user_id, 'Declined')
        
        return {
            'status': 'Declined',
            'message': 'Request timeout',
            'response_time': response_time,
            'formatted_response': formatted
        }
        
    except Exception as e:
        response_time = time.time() - start_time
        
        return {
            'status': 'Error',
            'message': str(e),
            'response_time': response_time,
            'formatted_response': None
        }


async def get_bin_info(bin_number: str) -> Dict:
    """
    Get BIN information
    """
    
    try:
        url = config.BIN_API_URL.format(bin_number)
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    from utils.helpers import get_country_flag
                    
                    return {
                        'brand': data.get('brand', 'Unknown').upper(),
                        'type': data.get('type', 'Unknown').upper(),
                        'level': data.get('level', 'Unknown').upper(),
                        'bank': data.get('bank', 'Unknown'),
                        'country': data.get('country', {}).get('name', 'Unknown'),
                        'flag': get_country_flag(data.get('country', {}).get('alpha2', ''))
                    }
    except:
        pass
    
    return {
        'brand': 'Unknown',
        'type': 'Unknown',
        'level': 'Unknown',
        'bank': 'Unknown',
        'country': 'Unknown',
        'flag': '🌍'
    }


async def mass_check_cards(card_list: list, gateway_name: str, user_id: int, **kwargs):
    """
    Mass check multiple cards
    
    Yields results one by one
    """
    
    for i, card_string in enumerate(card_list[:config.MASS_CHECK_LIMIT], 1):
        result = await check_card_with_gateway(card_string, gateway_name, user_id, **kwargs)
        
        yield {
            'index': i,
            'total': min(len(card_list), config.MASS_CHECK_LIMIT),
            'result': result
        }
        
        # Small delay between checks
        if i < len(card_list):
            await asyncio.sleep(1)


def get_available_gateways() -> list:
    """
    Get list of available gateways
    """
    
    gateways = []
    gates_dir = "gates"
    
    if os.path.exists(gates_dir):
        for file in os.listdir(gates_dir):
            if file.endswith('.py') and not file.startswith('_'):
                gateway_name = file[:-3]  # Remove .py
                
                # Skip utility files
                if gateway_name in ['utilities', 'gateway_utils', 'response_parser', 'cache', 'error_types']:
                    continue
                
                gateways.append(gateway_name)
    
    return sorted(gateways)


# Test
if __name__ == '__main__':
    print("Available gateways:")
    for gw in get_available_gateways():
        print(f"  - {gw}")
