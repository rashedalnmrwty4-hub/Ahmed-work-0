"""
UI Handler - All UI logic for Ex bot style
"""

from telethon import Button
from datetime import datetime
import config

def get_start_message(user_id: int, user_stats: dict) -> str:
    """
    Get start message in Ex bot style
    """
    
    current_date = datetime.now().strftime("%Y-%m-%d")
    current_time = datetime.now().strftime("%H:%M:%S.%f")
    
    message = f"""━━━━━━━━━━━━━━━━━━━━━━
{config.BOT_NAME}
━━━━━━━━━━━━━━━━━━━━━━

𝗣𝗹𝗮𝗻 ➜ Premium
𝗗𝗮𝘁𝗲 ➜ {current_date}
{current_time}
𝗨𝘀𝗲𝗿 𝗜𝗗 ➜ {user_id}
𝗖𝗿𝗲𝗱𝗶𝘁𝘀 ➜ Unlimited
𝗚𝗮𝘁𝗲𝘀 𝗨𝘀𝗮𝗴𝗲 ➜ {user_stats.get('total_checks', 0)}

𝗥𝗲𝗾𝘂𝗲𝘀𝘁𝗲𝗱 𝗕𝘆 ➜ {config.OWNER_USERNAME}
[Premium]"""
    
    return message


def get_start_buttons():
    """
    Get start message inline buttons
    """
    
    buttons = [
        [
            Button.inline("🎯 Auth", b"menu_auth"),
            Button.inline("💰 Charge", b"menu_charge"),
            Button.inline("💳 CCN+S", b"menu_ccn"),
        ],
        [
            Button.inline("📦 Mass", b"menu_mass"),
            Button.inline("🏠 HOME", b"menu_home"),
        ],
        [
            Button.inline("🔧 GATES", b"menu_gates"),
            Button.inline("🛠️ TOOLS", b"menu_tools"),
            Button.inline("🏪 Self Shop", b"menu_selfshop"),
        ],
        [
            Button.inline("❌ CLOSE", b"menu_close"),
        ]
    ]
    
    return buttons


def get_gates_menu_message() -> str:
    """
    Get gates menu message
    """
    
    message = f"""━━━━━━━━━━━━━━━━━━━━━━
⚔️ 𝗚𝗮𝘁𝗲𝘄𝗮𝘆𝘀 ⚔️
━━━━━━━━━━━━━━━━━━━━━━

𝗧𝗼𝘁𝗮𝗹 ➜ 51+

𝗚𝗮𝘁𝗲 𝗢𝗻 ➜ 45 ✅
𝗚𝗮𝘁𝗲 𝗢𝗳𝗳 ➜ 6 ❌
𝗦𝗲𝗹𝗳 𝗚𝗮𝘁𝗲 ➜ 5 ⭐
𝗠𝗮𝘀𝘀 𝗚𝗮𝘁𝗲𝘀 ➜ 10 📦

𝗧𝗼𝗼𝗹𝘀 ➜ 6 🛠️

Nice To Meet My Friend I'm {config.BOT_NAME}

━━━━━━━━━━━━━━━━━━━━━━
⚔️ {config.BOT_NAME} ⚔️
━━━━━━━━━━━━━━━━━━━━━━"""
    
    return message


def get_tools_menu_message() -> str:
    """
    Get tools menu message
    """
    
    message = f"""━━━━━━━━━━━━━━━━━━━━━━
🛠️ 𝗧𝗼𝗼𝗹𝘀 🛠️
━━━━━━━━━━━━━━━━━━━━━━

/bin <bin> - BIN Lookup
/gen <bin> [count] - CC Generator
/filter <type> <value> - Filter Tool
/ss <url> - Screenshot
/binex - BIN Extraction
/info - User Info

━━━━━━━━━━━━━━━━━━━━━━
⚔️ {config.BOT_NAME} ⚔️
━━━━━━━━━━━━━━━━━━━━━━"""
    
    return message


def get_selfshop_menu_message() -> str:
    """
    Get self shop menu message
    """
    
    message = f"""━━━━━━━━━━━━━━━━━━━━━━
🏪 𝗦𝗲𝗹𝗳 𝗦𝗵𝗼𝗽 🏪
━━━━━━━━━━━━━━━━━━━━━━

𝗖𝗼𝗺𝗺𝗮𝗻𝗱 ➜ Set Shop URL
𝗨𝘀𝗲 ➜ /seturl [your_url]
𝗦𝘁𝗮𝘁𝘂𝘀 ➜ ACTIVE ✅
𝗧𝘆𝗽𝗲 ➜ Free

𝗖𝗼𝗺𝗺𝗮𝗻𝗱 ➜ Check Card Now
𝗨𝘀𝗲 ➜ /sh cc|m|y|cvv
𝗦𝘁𝗮𝘁𝘂𝘀 ➜ ACTIVE ✅
𝗧𝘆𝗽𝗲 ➜ Free

𝗖𝗼𝗺𝗺𝗮𝗻𝗱 ➜ Multiple Chk
𝗨𝘀𝗲 ➜ /masssh Line By Line CC
𝗦𝘁𝗮𝘁𝘂𝘀 ➜ ACTIVE ✅
𝗧𝘆𝗽𝗲 ➜ Free

𝗖𝗼𝗺𝗺𝗮𝗻𝗱 ➜ Check Card Now
𝗨𝘀𝗲 ➜ Reply .txt file
𝗦𝘁𝗮𝘁𝘂𝘀 ➜ ACTIVE ✅
𝗧𝘆𝗽𝗲 ➜ Free

𝗖𝗼𝗺𝗺𝗮𝗻𝗱 ➜ View Shop URL
𝗨𝘀𝗲 ➜ /vurl
𝗦𝘁𝗮𝘁𝘂𝘀 ➜ ACTIVE ✅
𝗧𝘆𝗽𝗲 ➜ Free

𝗖𝗼𝗺𝗺𝗮𝗻𝗱 ➜ Remove Shop URL
𝗨𝘀𝗲 ➜ /rmurl
𝗦𝘁𝗮𝘁𝘂𝘀 ➜ ACTIVE ✅
𝗧𝘆𝗽𝗲 ➜ Free

━━━━━━━━━━━━━━━━━━━━━━
⚔️ {config.BOT_NAME} ⚔️
━━━━━━━━━━━━━━━━━━━━━━"""
    
    return message


def format_card_response(card: str, status: str, message: str, gateway: str, price: str, bin_info: dict, time_taken: float) -> str:
    """
    Format card check response in Ex bot style
    """
    
    # Status emoji and header
    if status.upper() in ["CHARGED", "APPROVED"]:
        emoji = "✅"
        if status.upper() == "CHARGED":
            header = f"{emoji} 𝗖𝗛𝗔𝗥𝗚𝗘𝗗 {emoji}"
        else:
            header = f"{emoji} 𝗔𝗣𝗣𝗥𝗢𝗩𝗘𝗗 {emoji}"
    elif status.upper() == "KILLED":
        emoji = "💀"
        header = f"{emoji} 𝗞𝗜𝗟𝗟𝗘𝗗 {emoji}"
    else:
        emoji = "❌"
        header = f"{emoji} 𝗗𝗘𝗖𝗟𝗜𝗡𝗘𝗗 {emoji}"
    
    # Format response
    response = f"""━━━━━━━━━━━━━━━━━━━━━━
{header}
━━━━━━━━━━━━━━━━━━━━━━

𝗖𝗮𝗿𝗱 ➜ {card}
𝗦𝘁𝗮𝘁𝘂𝘀 ➜ {emoji} {status}
𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 ➜ {message}
𝗚𝗮𝘁𝗲𝘄𝗮𝘆 ➜ {gateway}
𝗣𝗿𝗶𝗰𝗲 ➜ {price}

𝗕𝗜𝗡 𝗜𝗻𝗳𝗼
⤷ 𝗕𝗿𝗮𝗻𝗱 ➜ {bin_info.get('brand', 'Unknown')} | {bin_info.get('type', 'Unknown')} | {bin_info.get('level', 'Unknown')}
⤷ 𝗕𝗮𝗻𝗸 ➜ {bin_info.get('bank', 'Unknown')}
⤷ 𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ➜ {bin_info.get('country', 'Unknown')} {bin_info.get('flag', '')}

𝗧𝗶𝗺𝗲 ➜ {time_taken:.2f}s
𝗕𝗼𝘁 𝗕𝘆 ➜ {config.OWNER_USERNAME}
"""
    
    return response


def get_processing_message(gateway: str) -> str:
    """
    Get processing message
    """
    
    return f"⏳ Processing {gateway} check..."


def get_error_message(error: str) -> str:
    """
    Get error message
    """
    
    return f"❌ Error: {error}"


# Test
if __name__ == '__main__':
    print(get_start_message(123456, {"total_checks": 10}))
    print("---")
    print(get_gates_menu_message())
