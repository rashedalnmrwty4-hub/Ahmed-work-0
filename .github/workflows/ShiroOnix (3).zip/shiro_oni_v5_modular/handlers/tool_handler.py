"""
Tool Handler - All tool logic
"""

import aiohttp
import json
import config
from utils.card_parser import parse_card, get_card_brand, validate_luhn
from utils.helpers import get_user_stats, get_country_flag

async def bin_lookup(bin_number: str) -> str:
    """
    BIN Lookup tool
    """
    
    try:
        url = config.BIN_API_URL.format(bin_number)
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    result = f"""━━━━━━━━━━━━━━━━━━━━━━
🔍 𝗕𝗜𝗡 𝗟𝗼𝗼𝗸𝘂𝗽 🔍
━━━━━━━━━━━━━━━━━━━━━━

𝗕𝗜𝗡 ➜ {bin_number}

𝗕𝗿𝗮𝗻𝗱 ➜ {data.get('brand', 'Unknown').upper()}
𝗧𝘆𝗽𝗲 ➜ {data.get('type', 'Unknown').upper()}
𝗟𝗲𝘃𝗲𝗹 ➜ {data.get('level', 'Unknown').upper()}
𝗕𝗮𝗻𝗸 ➜ {data.get('bank', 'Unknown')}
𝗖𝗼𝘂𝗻𝘁𝗿𝘆 ➜ {data.get('country', {}).get('name', 'Unknown')} {get_country_flag(data.get('country', {}).get('alpha2', ''))}
𝗖𝘂𝗿𝗿𝗲𝗻𝗰𝘆 ➜ {data.get('country', {}).get('currency', 'Unknown')}

𝗕𝗼𝘁 𝗕𝘆 ➜ {config.OWNER_USERNAME}
"""
                    return result
                else:
                    return f"❌ BIN {bin_number} not found"
                    
    except Exception as e:
        return f"❌ Error: {str(e)}"


async def cc_generator(bin_number: str, count: int = 10) -> str:
    """
    CC Generator tool
    """
    
    try:
        if count > 50:
            count = 50
        
        url = f"{config.CC_GEN_API_URL}?bin={bin_number}&count={count}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    
                    if 'cards' in data:
                        cards = data['cards']
                        
                        result = f"""━━━━━━━━━━━━━━━━━━━━━━
💳 𝗖𝗖 𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗼𝗿 💳
━━━━━━━━━━━━━━━━━━━━━━

𝗕𝗜𝗡 ➜ {bin_number}
𝗖𝗼𝘂𝗻𝘁 ➜ {len(cards)}

𝗖𝗮𝗿𝗱𝘀:
"""
                        for card in cards:
                            result += f"{card}\n"
                        
                        result += f"\n𝗕𝗼𝘁 𝗕𝘆 ➜ {config.OWNER_USERNAME}"
                        
                        return result
                    else:
                        return "❌ No cards generated"
                else:
                    return f"❌ Error generating cards"
                    
    except Exception as e:
        return f"❌ Error: {str(e)}"


async def screenshot_tool(url: str) -> dict:
    """
    Screenshot tool
    
    Returns:
        dict: {success: bool, image_url: str, error: str}
    """
    
    try:
        screenshot_url = f"{config.SCREENSHOT_API_URL}?access_key={config.SCREENSHOT_API_KEY}&wait_until=page_loaded&url={url}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(screenshot_url, timeout=30) as response:
                if response.status == 200:
                    # Save image
                    image_data = await response.read()
                    
                    import os
                    os.makedirs("data/screenshots", exist_ok=True)
                    
                    filename = f"data/screenshots/{url.replace('://', '_').replace('/', '_')[:50]}.png"
                    
                    with open(filename, 'wb') as f:
                        f.write(image_data)
                    
                    return {
                        'success': True,
                        'image_path': filename,
                        'error': None
                    }
                else:
                    return {
                        'success': False,
                        'image_path': None,
                        'error': f'HTTP {response.status}'
                    }
                    
    except Exception as e:
        return {
            'success': False,
            'image_path': None,
            'error': str(e)
        }


async def filter_tool(filter_type: str, filter_value: str, cards: list) -> str:
    """
    Filter tool
    """
    
    try:
        filtered = []
        
        if filter_type == 'bin':
            for card_str in cards:
                card = parse_card(card_str)
                if card and card['number'].startswith(filter_value):
                    filtered.append(card_str)
        
        elif filter_type == 'brand':
            for card_str in cards:
                card = parse_card(card_str)
                if card and get_card_brand(card['number']).lower() == filter_value.lower():
                    filtered.append(card_str)
        
        elif filter_type == 'unique':
            seen = set()
            for card_str in cards:
                if card_str not in seen:
                    filtered.append(card_str)
                    seen.add(card_str)
        
        else:
            return f"❌ Invalid filter type. Use: bin, brand, unique"
        
        if filtered:
            result = f"""━━━━━━━━━━━━━━━━━━━━━━
🔍 𝗙𝗶𝗹𝘁𝗲𝗿 𝗥𝗲𝘀𝘂𝗹𝘁𝘀 🔍
━━━━━━━━━━━━━━━━━━━━━━

𝗙𝗶𝗹𝘁𝗲𝗿 ➜ {filter_type}
𝗩𝗮𝗹𝘂𝗲 ➜ {filter_value}
𝗖𝗼𝘂𝗻𝘁 ➜ {len(filtered)}

𝗖𝗮𝗿𝗱𝘀:
"""
            for card in filtered[:20]:  # Limit to 20
                result += f"{card}\n"
            
            if len(filtered) > 20:
                result += f"\n... and {len(filtered) - 20} more"
            
            result += f"\n𝗕𝗼𝘁 𝗕𝘆 ➜ {config.OWNER_USERNAME}"
            
            return result
        else:
            return "❌ No cards matched the filter"
            
    except Exception as e:
        return f"❌ Error: {str(e)}"


async def bin_extraction(cards: list) -> str:
    """
    BIN Extraction tool
    """
    
    try:
        bins = set()
        
        for card_str in cards:
            card = parse_card(card_str)
            if card:
                bins.add(card['number'][:6])
        
        if bins:
            result = f"""━━━━━━━━━━━━━━━━━━━━━━
📊 𝗕𝗜𝗡 𝗘𝘅𝘁𝗿𝗮𝗰𝘁𝗶𝗼𝗻 📊
━━━━━━━━━━━━━━━━━━━━━━

𝗧𝗼𝘁𝗮𝗹 𝗕𝗜𝗡𝘀 ➜ {len(bins)}

𝗕𝗜𝗡𝘀:
"""
            for bin_num in sorted(bins):
                brand = get_card_brand(bin_num + "000000")
                result += f"{bin_num} - {brand}\n"
            
            result += f"\n𝗕𝗼𝘁 𝗕𝘆 ➜ {config.OWNER_USERNAME}"
            
            return result
        else:
            return "❌ No valid cards found"
            
    except Exception as e:
        return f"❌ Error: {str(e)}"


async def user_info_tool(user_id: int) -> str:
    """
    User Info tool
    """
    
    try:
        stats = await get_user_stats(user_id)
        
        result = f"""━━━━━━━━━━━━━━━━━━━━━━
👤 𝗨𝘀𝗲𝗿 𝗜𝗻𝗳𝗼 👤
━━━━━━━━━━━━━━━━━━━━━━

𝗨𝘀𝗲𝗿 𝗜𝗗 ➜ {user_id}
𝗝𝗼𝗶𝗻 𝗗𝗮𝘁𝗲 ➜ {stats.get('join_date', 'Unknown')}
𝗧𝗼𝘁𝗮𝗹 𝗖𝗵𝗲𝗰𝗸𝘀 ➜ {stats.get('total_checks', 0)}
𝗔𝗽𝗽𝗿𝗼𝘃𝗲𝗱 ➜ {stats.get('approved', 0)}
𝗗𝗲𝗰𝗹𝗶𝗻𝗲𝗱 ➜ {stats.get('declined', 0)}
𝗧𝗼𝘁𝗮𝗹 𝗦𝗶𝘁𝗲𝘀 ➜ {stats.get('total_sites', 0)}

𝗕𝗼𝘁 𝗕𝘆 ➜ {config.OWNER_USERNAME}
"""
        
        return result
        
    except Exception as e:
        return f"❌ Error: {str(e)}"


# Test
if __name__ == '__main__':
    import asyncio
    
    async def test():
        result = await bin_lookup("453212")
        print(result)
    
    asyncio.run(test())
